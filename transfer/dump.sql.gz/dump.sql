-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: domain
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_actionscheduler_actions`
--

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint unsigned NOT NULL DEFAULT '0',
  `attempts` int NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_actionscheduler_actions`
--

LOCK TABLES `wp_actionscheduler_actions` WRITE;
/*!40000 ALTER TABLE `wp_actionscheduler_actions` DISABLE KEYS */;
INSERT INTO `wp_actionscheduler_actions` VALUES (6,'action_scheduler/migration_hook','pending','2022-11-19 08:13:31','2022-11-19 08:13:31','[]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1668845611;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1668845611;}',1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(7,'woocommerce_cleanup_draft_orders','pending','2022-11-19 08:12:32','2022-11-19 08:12:32','[]','O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1668845552;s:18:\"\0*\0first_timestamp\";i:1668845552;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1668845552;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(8,'woocommerce_run_product_attribute_lookup_update_callback','pending','2022-11-19 08:26:16','2022-11-19 08:26:16','[11,1]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1668846376;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1668846376;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(9,'woocommerce_update_marketplace_suggestions','pending','2022-11-19 08:26:29','2022-11-19 08:26:29','[]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1668846389;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1668846389;}',0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(10,'woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications','pending','0000-00-00 00:00:00','0000-00-00 00:00:00','[]','O:28:\"ActionScheduler_NullSchedule\":0:{}',0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(11,'wc-admin_import_customers','pending','2022-11-20 12:57:12','2022-11-20 12:57:12','[1]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1668949032;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1668949032;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(12,'wc-admin_import_orders','pending','2022-11-21 06:27:30','2022-11-21 06:27:30','[19]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669012050;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669012050;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(13,'wc-admin_import_orders','pending','2022-11-22 08:14:49','2022-11-22 08:14:49','[20]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669104889;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669104889;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(14,'wc-admin_import_orders','pending','2022-11-22 08:18:38','2022-11-22 08:18:38','[21]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669105118;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669105118;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(15,'wc-admin_import_orders','pending','2022-11-22 10:33:09','2022-11-22 10:33:09','[22]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669113189;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669113189;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(16,'wc-admin_import_orders','pending','2022-11-22 10:53:20','2022-11-22 10:53:20','[23]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669114400;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669114400;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(17,'wc-admin_import_orders','pending','2022-11-22 12:42:38','2022-11-22 12:42:38','[24]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669120958;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669120958;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(18,'wc-admin_import_orders','pending','2022-11-22 12:43:02','2022-11-22 12:43:02','[25]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669120982;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669120982;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(19,'wc-admin_import_orders','pending','2022-11-22 12:54:20','2022-11-22 12:54:20','[26]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669121660;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669121660;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(20,'wc-admin_import_orders','pending','2022-11-23 03:36:11','2022-11-23 03:36:11','[27]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669174571;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669174571;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(21,'wc-admin_import_orders','pending','2022-11-23 03:38:00','2022-11-23 03:38:00','[28]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669174680;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669174680;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(22,'wc-admin_import_orders','pending','2022-11-23 03:38:27','2022-11-23 03:38:27','[29]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669174707;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669174707;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(23,'mailpoet/cron/daemon-trigger','canceled','2022-11-24 02:44:25','2022-11-24 02:44:25','[]','O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1669257865;s:18:\"\0*\0first_timestamp\";i:1669257865;s:13:\"\0*\0recurrence\";i:120;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1669257865;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:120;}',4,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(24,'wc-admin_import_orders','pending','2022-11-24 03:29:53','2022-11-24 03:29:53','[31]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669260593;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669260593;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(25,'wc-admin_import_orders','pending','2022-11-25 02:55:15','2022-11-25 02:55:15','[32]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669344915;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669344915;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(26,'wc-admin_import_orders','pending','2022-11-25 05:32:52','2022-11-25 05:32:52','[44]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669354372;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669354372;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(27,'wc-admin_import_orders','pending','2022-11-25 05:53:50','2022-11-25 05:53:50','[45]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669355630;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669355630;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(28,'wc-admin_import_orders','pending','2022-11-25 10:21:46','2022-11-25 10:21:46','[46]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669371706;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669371706;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(29,'wc-admin_import_orders','pending','2022-11-25 11:39:30','2022-11-25 11:39:30','[47]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669376370;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669376370;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(30,'wc-admin_import_orders','pending','2022-11-25 11:42:36','2022-11-25 11:42:36','[48]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669376556;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669376556;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(31,'wc-admin_import_orders','pending','2022-11-28 07:25:51','2022-11-28 07:25:51','[49]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669620351;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669620351;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),(32,'wc-admin_import_orders','pending','2022-11-28 08:32:16','2022-11-28 08:32:16','[50]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1669624336;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1669624336;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL);
/*!40000 ALTER TABLE `wp_actionscheduler_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_actionscheduler_claims`
--

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_actionscheduler_claims`
--

LOCK TABLES `wp_actionscheduler_claims` WRITE;
/*!40000 ALTER TABLE `wp_actionscheduler_claims` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_actionscheduler_claims` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_actionscheduler_groups`
--

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_actionscheduler_groups`
--

LOCK TABLES `wp_actionscheduler_groups` WRITE;
/*!40000 ALTER TABLE `wp_actionscheduler_groups` DISABLE KEYS */;
INSERT INTO `wp_actionscheduler_groups` VALUES (1,'action-scheduler-migration'),(2,'woocommerce-db-updates'),(3,'wc-admin-data'),(4,'mailpoet-cron');
/*!40000 ALTER TABLE `wp_actionscheduler_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_actionscheduler_logs`
--

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint unsigned NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_actionscheduler_logs`
--

LOCK TABLES `wp_actionscheduler_logs` WRITE;
/*!40000 ALTER TABLE `wp_actionscheduler_logs` DISABLE KEYS */;
INSERT INTO `wp_actionscheduler_logs` VALUES (1,6,'action created','2022-11-19 08:12:31','2022-11-19 08:12:31'),(2,7,'action created','2022-11-19 08:12:32','2022-11-19 08:12:32'),(3,8,'action created','2022-11-19 08:26:15','2022-11-19 08:26:15'),(4,9,'action created','2022-11-19 08:26:29','2022-11-19 08:26:29'),(5,10,'action created','2022-11-19 12:00:54','2022-11-19 12:00:54'),(6,11,'action created','2022-11-20 12:57:07','2022-11-20 12:57:07'),(7,12,'action created','2022-11-21 06:27:25','2022-11-21 06:27:25'),(8,13,'action created','2022-11-22 08:14:44','2022-11-22 08:14:44'),(9,14,'action created','2022-11-22 08:18:33','2022-11-22 08:18:33'),(10,15,'action created','2022-11-22 10:33:04','2022-11-22 10:33:04'),(11,16,'action created','2022-11-22 10:53:15','2022-11-22 10:53:15'),(12,17,'操作已创建','2022-11-22 12:42:33','2022-11-22 12:42:33'),(13,18,'操作已创建','2022-11-22 12:42:57','2022-11-22 12:42:57'),(14,19,'操作已创建','2022-11-22 12:54:15','2022-11-22 12:54:15'),(15,20,'操作已创建','2022-11-23 03:36:06','2022-11-23 03:36:06'),(16,21,'操作已创建','2022-11-23 03:37:55','2022-11-23 03:37:55'),(17,22,'操作已创建','2022-11-23 03:38:22','2022-11-23 03:38:22'),(18,23,'action created','2022-11-24 02:44:25','2022-11-24 02:44:25'),(19,23,'action canceled','2022-11-24 02:46:27','2022-11-24 02:46:27'),(20,23,'action canceled','2022-11-24 02:46:27','2022-11-24 02:46:27'),(21,24,'action created','2022-11-24 03:29:49','2022-11-24 03:29:49'),(22,25,'action created','2022-11-25 02:55:10','2022-11-25 02:55:10'),(23,26,'action created','2022-11-25 05:32:47','2022-11-25 05:32:47'),(24,27,'action created','2022-11-25 05:53:45','2022-11-25 05:53:45'),(25,28,'action created','2022-11-25 10:21:41','2022-11-25 10:21:41'),(26,29,'action created','2022-11-25 11:39:25','2022-11-25 11:39:25'),(27,30,'action created','2022-11-25 11:42:31','2022-11-25 11:42:31'),(28,31,'action created','2022-11-28 07:25:46','2022-11-28 07:25:46'),(29,32,'action created','2022-11-28 08:32:11','2022-11-28 08:32:11');
/*!40000 ALTER TABLE `wp_actionscheduler_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_commentmeta`
--

LOCK TABLES `wp_commentmeta` WRITE;
/*!40000 ALTER TABLE `wp_commentmeta` DISABLE KEYS */;
INSERT INTO `wp_commentmeta` VALUES (1,22,'is_customer_note','1'),(2,23,'is_customer_note','11');
/*!40000 ALTER TABLE `wp_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint unsigned NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_comments`
--

LOCK TABLES `wp_comments` WRITE;
/*!40000 ALTER TABLE `wp_comments` DISABLE KEYS */;
INSERT INTO `wp_comments` VALUES (1,1,'A WordPress Commenter','wapuu@wordpress.example','https://wordpress.org/','','2022-11-19 06:24:19','2022-11-19 06:24:19','Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.',0,'1','','comment',0,0),(2,19,'WooCommerce','','','','2022-11-22 16:13:59','2022-11-22 08:13:59','Payment to be made upon delivery. Order status changed from Pending payment to Processing.',0,'1','WooCommerce','order_note',0,0),(3,20,'WooCommerce','','','','2022-11-22 16:14:46','2022-11-22 08:14:46','PayerMax transaction ID: 2022112208144620',0,'1','WooCommerce','order_note',0,0),(4,21,'WooCommerce','','','','2022-11-22 16:18:35','2022-11-22 08:18:35','PayerMax transaction ID: 2022112208183521',0,'1','WooCommerce','order_note',0,0),(5,20,'WooCommerce','','','','2022-11-22 18:24:57','2022-11-22 10:24:57','Order cancelled by customer. Order status changed from Pending payment to Cancelled.',0,'1','WooCommerce','order_note',0,0),(6,21,'WooCommerce','','','','2022-11-22 18:32:21','2022-11-22 10:32:21','Payment to be made upon delivery. Order status changed from Pending payment to Processing.',0,'1','WooCommerce','order_note',0,0),(7,22,'WooCommerce','','','','2022-11-22 18:33:06','2022-11-22 10:33:06','PayerMax transaction ID: 2022112210330622',0,'1','WooCommerce','order_note',0,0),(8,22,'WooCommerce','','','','2022-11-22 18:40:06','2022-11-22 10:40:06','Payment to be made upon delivery. Order status changed from Pending payment to Processing.',0,'1','WooCommerce','order_note',0,0),(9,23,'WooCommerce','','','','2022-11-22 18:53:17','2022-11-22 10:53:17','PayerMax transaction ID: 2022112210531723',0,'1','WooCommerce','order_note',0,0),(10,21,'WooCommerce','','','','2022-11-22 20:54:15','2022-11-22 12:54:15','订单状态由 正在处理 变更为 已退款 。',0,'1','WooCommerce','order_note',0,0),(11,22,'admin','yao3060@gmail.com','','','2022-11-23 11:37:12','2022-11-23 03:37:12','订单状态由 正在处理 变更为 已完成 。',0,'1','WooCommerce','order_note',0,0),(12,22,'WooCommerce','','','','2022-11-23 11:38:22','2022-11-23 03:38:22','订单状态由 已完成 变更为 已退款 。',0,'1','WooCommerce','order_note',0,0),(13,31,'WooCommerce','','','','2022-11-24 11:29:51','2022-11-24 03:29:51','PayerMax transaction ID: 2022112403295031',0,'1','WooCommerce','order_note',0,0),(14,31,'WooCommerce','','','','2022-11-24 20:30:25','2022-11-24 12:30:25','Awaiting payermax payment Order status changed from Pending payment to On hold.',0,'1','WooCommerce','order_note',0,0),(15,31,'WooCommerce','','','','2022-11-24 20:30:37','2022-11-24 12:30:37','Set transaction ID: 2022112412303731',0,'1','WooCommerce','order_note',0,0),(16,31,'WooCommerce','','','','2022-11-25 10:07:11','2022-11-25 02:07:11','Order status changed from On hold to Processing.',0,'1','WooCommerce','order_note',0,0),(17,32,'WooCommerce','','','','2022-11-25 10:55:13','2022-11-25 02:55:13','Awaiting payermax payment Order status changed from Pending payment to On hold.',0,'1','WooCommerce','order_note',0,0),(18,32,'WooCommerce','','','','2022-11-25 10:55:23','2022-11-25 02:55:23','Set transaction ID: 2022112502552332',0,'1','WooCommerce','order_note',0,0),(19,32,'WooCommerce','','','','2022-11-25 10:56:02','2022-11-25 02:56:02','Order status changed from On hold to Processing.',0,'1','WooCommerce','order_note',0,0),(20,32,'WooCommerce','','','','2022-11-25 13:32:42','2022-11-25 05:32:42','Refund Status: REFUND_PENDING - Refund ID: 20221125053241TI8303579900396579',0,'1','WooCommerce','order_note',0,0),(21,32,'WooCommerce','','','','2022-11-25 13:53:40','2022-11-25 05:53:40','Refund Status: REFUND_PENDING - Refund ID: 20221125055340TI6611911500396641',0,'1','WooCommerce','order_note',0,0),(22,32,'admin','yao3060@gmail.com','','','2022-11-25 13:55:18','2022-11-25 05:55:18','test client note',0,'1','WooCommerce','order_note',0,0),(23,32,'WooCommerce','','','','2022-11-25 16:00:48','2022-11-25 08:00:48','PayerMax Refund succeed; Refund ID: 20220117091657TI790000055087 ; Refund Amount: 10000',0,'1','WooCommerce','order_note',0,0),(24,46,'WooCommerce','','','','2022-11-25 18:21:44','2022-11-25 10:21:44','Awaiting payermax payment Order status changed from Pending payment to On hold.',0,'1','WooCommerce','order_note',0,0),(25,46,'WooCommerce','','','','2022-11-25 18:21:53','2022-11-25 10:21:53','Set transaction ID: 2022112510215346',0,'1','WooCommerce','order_note',0,0),(26,46,'WooCommerce','','','','2022-11-25 18:22:39','2022-11-25 10:22:39','Order status changed from On hold to Processing.',0,'1','WooCommerce','order_note',0,0),(27,47,'WooCommerce','','','','2022-11-25 19:39:29','2022-11-25 11:39:29','Awaiting payermax payment Order status changed from Pending payment to On hold.',0,'1','WooCommerce','order_note',0,0),(28,47,'WooCommerce','','','','2022-11-25 19:39:39','2022-11-25 11:39:39','Set transaction ID: 2022112511393947',0,'1','WooCommerce','order_note',0,0),(29,47,'WooCommerce','','','','2022-11-25 19:40:03','2022-11-25 11:40:03','Order status changed from On hold to Processing.',0,'1','WooCommerce','order_note',0,0),(30,47,'WooCommerce','','','','2022-11-25 19:42:25','2022-11-25 11:42:25','Refund Status: REFUND_PENDING - Refund ID: 20221125114227TI3995149100398329',0,'1','WooCommerce','order_note',0,0),(31,23,'admin','yao3060@gmail.com','','','2022-11-28 15:16:50','2022-11-28 07:16:50','Order status changed from Pending payment to Failed.',0,'1','WooCommerce','order_note',0,0),(32,23,'WooCommerce','','','','2022-11-28 15:17:51','2022-11-28 07:17:51','Awaiting payermax payment Order status changed from Failed to On hold.',0,'1','WooCommerce','order_note',0,0),(33,23,'WooCommerce','','','','2022-11-28 15:18:04','2022-11-28 07:18:04','Set transaction ID: 2022112807180423',0,'1','WooCommerce','order_note',0,0),(34,23,'WooCommerce','','','','2022-11-28 15:23:08','2022-11-28 07:23:08','Order status changed from On hold to Processing.',0,'1','WooCommerce','order_note',0,0),(35,23,'WooCommerce','','','','2022-11-28 15:23:13','2022-11-28 07:23:13','PayerMax Trade Token is: TOKEN202211280000490537',0,'1','WooCommerce','order_note',0,0),(36,49,'WooCommerce','','','','2022-11-28 15:25:49','2022-11-28 07:25:49','Awaiting payermax payment Order status changed from Pending payment to On hold.',0,'1','WooCommerce','order_note',0,0),(37,49,'WooCommerce','','','','2022-11-28 15:25:58','2022-11-28 07:25:58','Set transaction ID: 2022112807255849',0,'1','WooCommerce','order_note',0,0),(38,49,'WooCommerce','','','','2022-11-28 16:13:02','2022-11-28 08:13:02','Order status changed from On hold to Failed.',0,'1','WooCommerce','order_note',0,0),(39,49,'WooCommerce','','','','2022-11-28 16:13:05','2022-11-28 08:13:05','PayerMax Payment Failed, Trade Token: TOKEN202211280000490551, Result message: This order has been closed.',0,'1','WooCommerce','order_note',0,0),(40,50,'WooCommerce','','','','2022-11-28 16:32:13','2022-11-28 08:32:13','Awaiting payermax payment Order status changed from Pending payment to On hold.',0,'1','WooCommerce','order_note',0,0),(41,50,'WooCommerce','','','','2022-11-28 16:32:23','2022-11-28 08:32:23','Set transaction ID: 2022112808322350',0,'1','WooCommerce','order_note',0,0);
/*!40000 ALTER TABLE `wp_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_links` (
  `link_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint unsigned NOT NULL DEFAULT '1',
  `link_rating` int NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_links`
--

LOCK TABLES `wp_links` WRITE;
/*!40000 ALTER TABLE `wp_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_options` (
  `option_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=310 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_options`
--

LOCK TABLES `wp_options` WRITE;
/*!40000 ALTER TABLE `wp_options` DISABLE KEYS */;
INSERT INTO `wp_options` VALUES (1,'siteurl','http://localhost:8000','yes'),(2,'home','http://localhost:8000','yes'),(3,'blogname','WordPress 5.8.6','yes'),(4,'blogdescription','Just another WordPress site','yes'),(5,'users_can_register','0','yes'),(6,'admin_email','yao3060@gmail.com','yes'),(7,'start_of_week','0','yes'),(8,'use_balanceTags','0','yes'),(9,'use_smilies','1','yes'),(10,'require_name_email','1','yes'),(11,'comments_notify','1','yes'),(12,'posts_per_rss','10','yes'),(13,'rss_use_excerpt','0','yes'),(14,'mailserver_url','mail.example.com','yes'),(15,'mailserver_login','login@example.com','yes'),(16,'mailserver_pass','password','yes'),(17,'mailserver_port','110','yes'),(18,'default_category','1','yes'),(19,'default_comment_status','open','yes'),(20,'default_ping_status','open','yes'),(21,'default_pingback_flag','0','yes'),(22,'posts_per_page','10','yes'),(23,'date_format','F j, Y','yes'),(24,'time_format','g:i a','yes'),(25,'links_updated_date_format','F j, Y g:i a','yes'),(26,'comment_moderation','0','yes'),(27,'moderation_notify','1','yes'),(28,'permalink_structure','/%postname%/','yes'),(29,'rewrite_rules','a:161:{s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:7:\"shop/?$\";s:27:\"index.php?post_type=product\";s:37:\"shop/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:32:\"shop/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:24:\"shop/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=12&cpage=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:25:\"([^/]+)/wc-api(/(.*))?/?$\";s:45:\"index.php?name=$matches[1]&wc-api=$matches[3]\";s:31:\"[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}','yes'),(30,'hack_file','0','yes'),(31,'blog_charset','UTF-8','yes'),(32,'moderation_keys','','no'),(33,'active_plugins','a:6:{i:0;s:45:\"disable-wordpress-updates/disable-updates.php\";i:1;s:23:\"loco-translate/loco.php\";i:2;s:27:\"redis-cache/redis-cache.php\";i:3;s:61:\"woocommerce-gateway-payermax/woocommerce-gateway-payermax.php\";i:4;s:27:\"woocommerce/woocommerce.php\";i:5;s:31:\"wp-serverinfo/wp-serverinfo.php\";}','yes'),(34,'category_base','','yes'),(35,'ping_sites','http://rpc.pingomatic.com/','yes'),(36,'comment_max_links','2','yes'),(37,'gmt_offset','8','yes'),(38,'default_email_category','1','yes'),(39,'recently_edited','','no'),(40,'template','storefront','yes'),(41,'stylesheet','storefront','yes'),(42,'comment_registration','0','yes'),(43,'html_type','text/html','yes'),(44,'use_trackback','0','yes'),(45,'default_role','subscriber','yes'),(46,'db_version','49752','yes'),(47,'uploads_use_yearmonth_folders','1','yes'),(48,'upload_path','','yes'),(49,'blog_public','0','yes'),(50,'default_link_category','2','yes'),(51,'show_on_front','page','yes'),(52,'tag_base','','yes'),(53,'show_avatars','1','yes'),(54,'avatar_rating','G','yes'),(55,'upload_url_path','','yes'),(56,'thumbnail_size_w','150','yes'),(57,'thumbnail_size_h','150','yes'),(58,'thumbnail_crop','1','yes'),(59,'medium_size_w','300','yes'),(60,'medium_size_h','300','yes'),(61,'avatar_default','mystery','yes'),(62,'large_size_w','1024','yes'),(63,'large_size_h','1024','yes'),(64,'image_default_link_type','none','yes'),(65,'image_default_size','','yes'),(66,'image_default_align','','yes'),(67,'close_comments_for_old_posts','0','yes'),(68,'close_comments_days_old','14','yes'),(69,'thread_comments','1','yes'),(70,'thread_comments_depth','5','yes'),(71,'page_comments','0','yes'),(72,'comments_per_page','50','yes'),(73,'default_comments_page','newest','yes'),(74,'comment_order','asc','yes'),(75,'sticky_posts','a:0:{}','yes'),(76,'widget_categories','a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(77,'widget_text','a:0:{}','yes'),(78,'widget_rss','a:0:{}','yes'),(79,'uninstall_plugins','a:0:{}','no'),(80,'timezone_string','','yes'),(81,'page_for_posts','0','yes'),(82,'page_on_front','12','yes'),(83,'default_post_format','0','yes'),(84,'link_manager_enabled','0','yes'),(85,'finished_splitting_shared_terms','1','yes'),(86,'site_icon','0','yes'),(87,'medium_large_size_w','768','yes'),(88,'medium_large_size_h','0','yes'),(89,'wp_page_for_privacy_policy','3','yes'),(90,'show_comments_cookies_opt_in','1','yes'),(91,'admin_email_lifespan','1684391058','yes'),(92,'disallowed_keys','','no'),(93,'comment_previously_approved','1','yes'),(94,'auto_plugin_theme_update_emails','a:0:{}','no'),(95,'auto_update_core_dev','enabled','yes'),(96,'auto_update_core_minor','enabled','yes'),(97,'auto_update_core_major','enabled','yes'),(98,'initial_db_version','49752','yes'),(99,'wp_user_roles','a:8:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:123:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:28:\"mailpoet_access_plugin_admin\";b:1;s:24:\"mailpoet_manage_settings\";b:1;s:24:\"mailpoet_manage_features\";b:1;s:22:\"mailpoet_manage_emails\";b:1;s:27:\"mailpoet_manage_subscribers\";b:1;s:21:\"mailpoet_manage_forms\";b:1;s:24:\"mailpoet_manage_segments\";b:1;s:27:\"mailpoet_manage_automations\";b:1;s:10:\"loco_admin\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:28:\"mailpoet_access_plugin_admin\";b:1;s:22:\"mailpoet_manage_emails\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:10:\"translator\";a:2:{s:4:\"name\";s:10:\"Translator\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:10:\"loco_admin\";b:1;}}}','yes'),(100,'fresh_site','0','yes'),(101,'widget_search','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(102,'widget_recent-posts','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(103,'widget_recent-comments','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(104,'widget_archives','a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(105,'widget_meta','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(106,'sidebars_widgets','a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:8:\"header-1\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}s:13:\"array_version\";i:3;}','yes'),(107,'cron','a:20:{i:1668839060;a:3:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1668839066;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1668839123;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1668839126;a:1:{s:28:\"wp_update_comment_type_batch\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1668839725;a:1:{s:11:\"wp_cache_gc\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1668845546;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"0d04ed39571b55704c122d726248bbac\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:1:{i:0;s:7:\"WP Cron\";}s:8:\"interval\";i:60;}}}i:1668845550;a:1:{s:14:\"wc_admin_daily\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1668845551;a:1:{s:33:\"wc_admin_process_orders_milestone\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1668845557;a:1:{s:29:\"wc_admin_unsnooze_admin_notes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1668845560;a:3:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:30:\"generate_category_lookup_table\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1668845610;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:11:\"fifteendays\";s:4:\"args\";a:0:{}s:8:\"interval\";i:1296000;}}}i:1668846293;a:1:{s:30:\"wp_1_wc_regenerate_images_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:39:\"wp_1_wc_regenerate_images_cron_interval\";s:4:\"args\";a:0:{}s:8:\"interval\";i:300;}}}i:1668846373;a:1:{s:31:\"woocommerce_flush_rewrite_rules\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1668849150;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1668856350;a:2:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:31:\"woocommerce_cleanup_rate_limits\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1668867150;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1668902400;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1668925460;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1669257840;a:1:{s:26:\"rediscache_discard_metrics\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}s:7:\"version\";i:2;}','yes'),(108,'wpsupercache_gc_time','1668839060','yes'),(109,'widget_pages','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(110,'widget_calendar','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(111,'widget_media_audio','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(112,'widget_media_image','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(113,'widget_media_gallery','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(114,'widget_media_video','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(115,'widget_tag_cloud','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(116,'widget_nav_menu','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(117,'widget_custom_html','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(118,'theme_mods_twentytwentyone','a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1668846293;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}}','yes'),(119,'can_compress_scripts','0','no'),(120,'recently_activated','a:3:{s:21:\"mailpoet/mailpoet.php\";i:1669257989;s:29:\"health-check/health-check.php\";i:1668941476;s:57:\"woocommerce-gateway-stripe/woocommerce-gateway-stripe.php\";i:1668940646;}','yes'),(121,'widget_block','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(122,'wp_force_deactivated_plugins','a:0:{}','yes'),(123,'action_scheduler_hybrid_store_demarkation','5','yes'),(124,'schema-ActionScheduler_StoreSchema','6.0.1668845545','yes'),(125,'schema-ActionScheduler_LoggerSchema','3.0.1668845546','yes'),(126,'woocommerce_schema_version','430','yes'),(127,'woocommerce_store_address','襄阳南路489号4F','yes'),(128,'woocommerce_store_address_2','','yes'),(129,'woocommerce_store_city','徐汇区','yes'),(130,'woocommerce_default_country','CN:CN10','yes'),(131,'woocommerce_store_postcode','200031','yes'),(132,'woocommerce_allowed_countries','all','yes'),(133,'woocommerce_all_except_countries','a:0:{}','yes'),(134,'woocommerce_specific_allowed_countries','a:0:{}','yes'),(135,'woocommerce_ship_to_countries','','yes'),(136,'woocommerce_specific_ship_to_countries','a:0:{}','yes'),(137,'woocommerce_default_customer_address','base','yes'),(138,'woocommerce_calc_taxes','no','yes'),(139,'woocommerce_enable_coupons','yes','yes'),(140,'woocommerce_calc_discounts_sequentially','no','no'),(141,'woocommerce_currency','USD','yes'),(142,'woocommerce_currency_pos','left','yes'),(143,'woocommerce_price_thousand_sep',',','yes'),(144,'woocommerce_price_decimal_sep','.','yes'),(145,'woocommerce_price_num_decimals','2','yes'),(146,'woocommerce_shop_page_id','5','yes'),(147,'woocommerce_cart_redirect_after_add','no','yes'),(148,'woocommerce_enable_ajax_add_to_cart','yes','yes'),(149,'woocommerce_placeholder_image','0','yes'),(150,'woocommerce_weight_unit','kg','yes'),(151,'woocommerce_dimension_unit','cm','yes'),(152,'woocommerce_enable_reviews','yes','yes'),(153,'woocommerce_review_rating_verification_label','yes','no'),(154,'woocommerce_review_rating_verification_required','no','no'),(155,'woocommerce_enable_review_rating','yes','yes'),(156,'woocommerce_review_rating_required','yes','no'),(157,'woocommerce_manage_stock','yes','yes'),(158,'woocommerce_hold_stock_minutes','60','no'),(159,'woocommerce_notify_low_stock','yes','no'),(160,'woocommerce_notify_no_stock','yes','no'),(161,'woocommerce_stock_email_recipient','yao3060@gmail.com','no'),(162,'woocommerce_notify_low_stock_amount','2','no'),(163,'woocommerce_notify_no_stock_amount','0','yes'),(164,'woocommerce_hide_out_of_stock_items','no','yes'),(165,'woocommerce_stock_format','','yes'),(166,'woocommerce_file_download_method','force','no'),(167,'woocommerce_downloads_redirect_fallback_allowed','no','no'),(168,'woocommerce_downloads_require_login','no','no'),(169,'woocommerce_downloads_grant_access_after_payment','yes','no'),(170,'woocommerce_downloads_add_hash_to_filename','yes','yes'),(171,'woocommerce_attribute_lookup_enabled','no','yes'),(172,'woocommerce_attribute_lookup_direct_updates','no','yes'),(173,'woocommerce_prices_include_tax','no','yes'),(174,'woocommerce_tax_based_on','shipping','yes'),(175,'woocommerce_shipping_tax_class','inherit','yes'),(176,'woocommerce_tax_round_at_subtotal','no','yes'),(177,'woocommerce_tax_classes','','yes'),(178,'woocommerce_tax_display_shop','excl','yes'),(179,'woocommerce_tax_display_cart','excl','yes'),(180,'woocommerce_price_display_suffix','','yes'),(181,'woocommerce_tax_total_display','itemized','no'),(182,'woocommerce_enable_shipping_calc','yes','no'),(183,'woocommerce_shipping_cost_requires_address','no','yes'),(184,'woocommerce_ship_to_destination','billing','no'),(185,'woocommerce_shipping_debug_mode','no','yes'),(186,'woocommerce_enable_guest_checkout','yes','no'),(187,'woocommerce_enable_checkout_login_reminder','no','no'),(188,'woocommerce_enable_signup_and_login_from_checkout','no','no'),(189,'woocommerce_enable_myaccount_registration','no','no'),(190,'woocommerce_registration_generate_username','yes','no'),(191,'woocommerce_registration_generate_password','yes','no'),(192,'woocommerce_erasure_request_removes_order_data','no','no'),(193,'woocommerce_erasure_request_removes_download_data','no','no'),(194,'woocommerce_allow_bulk_remove_personal_data','no','no'),(195,'woocommerce_registration_privacy_policy_text','Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].','yes'),(196,'woocommerce_checkout_privacy_policy_text','Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].','yes'),(197,'woocommerce_delete_inactive_accounts','a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}','no'),(198,'woocommerce_trash_pending_orders','','no'),(199,'woocommerce_trash_failed_orders','','no'),(200,'woocommerce_trash_cancelled_orders','','no'),(201,'woocommerce_anonymize_completed_orders','a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}','no'),(202,'woocommerce_email_from_name','WordPress V5','no'),(203,'woocommerce_email_from_address','yao3060@gmail.com','no'),(204,'woocommerce_email_header_image','','no'),(205,'woocommerce_email_footer_text','{site_title} &mdash; Built with {WooCommerce}','no'),(206,'woocommerce_email_base_color','#7f54b3','no'),(207,'woocommerce_email_background_color','#f7f7f7','no'),(208,'woocommerce_email_body_background_color','#ffffff','no'),(209,'woocommerce_email_text_color','#3c3c3c','no'),(210,'woocommerce_merchant_email_notifications','no','no'),(211,'woocommerce_cart_page_id','6','no'),(212,'woocommerce_checkout_page_id','7','no'),(213,'woocommerce_myaccount_page_id','8','no'),(214,'woocommerce_terms_page_id','','no'),(215,'woocommerce_force_ssl_checkout','no','yes'),(216,'woocommerce_unforce_ssl_checkout','no','yes'),(217,'woocommerce_checkout_pay_endpoint','order-pay','yes'),(218,'woocommerce_checkout_order_received_endpoint','order-received','yes'),(219,'woocommerce_myaccount_add_payment_method_endpoint','add-payment-method','yes'),(220,'woocommerce_myaccount_delete_payment_method_endpoint','delete-payment-method','yes'),(221,'woocommerce_myaccount_set_default_payment_method_endpoint','set-default-payment-method','yes'),(222,'woocommerce_myaccount_orders_endpoint','orders','yes'),(223,'woocommerce_myaccount_view_order_endpoint','view-order','yes'),(224,'woocommerce_myaccount_downloads_endpoint','downloads','yes'),(225,'woocommerce_myaccount_edit_account_endpoint','edit-account','yes'),(226,'woocommerce_myaccount_edit_address_endpoint','edit-address','yes'),(227,'woocommerce_myaccount_payment_methods_endpoint','payment-methods','yes'),(228,'woocommerce_myaccount_lost_password_endpoint','lost-password','yes'),(229,'woocommerce_logout_endpoint','customer-logout','yes'),(230,'woocommerce_api_enabled','yes','yes'),(231,'woocommerce_allow_tracking','no','no'),(232,'woocommerce_show_marketplace_suggestions','yes','no'),(233,'woocommerce_single_image_width','600','yes'),(234,'woocommerce_thumbnail_image_width','300','yes'),(235,'woocommerce_checkout_highlight_required_fields','yes','yes'),(236,'woocommerce_demo_store','no','no'),(237,'wc_downloads_approved_directories_mode','enabled','yes'),(238,'woocommerce_permalinks','a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}','yes'),(239,'current_theme_supports_woocommerce','yes','yes'),(240,'woocommerce_queue_flush_rewrite_rules','no','yes'),(242,'default_product_cat','15','yes'),(244,'woocommerce_refund_returns_page_id','9','yes'),(245,'woocommerce_paypal_settings','a:23:{s:7:\"enabled\";s:2:\"no\";s:5:\"title\";s:6:\"PayPal\";s:11:\"description\";s:85:\"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.\";s:5:\"email\";s:17:\"yao3060@gmail.com\";s:8:\"advanced\";s:0:\"\";s:8:\"testmode\";s:2:\"no\";s:5:\"debug\";s:2:\"no\";s:16:\"ipn_notification\";s:3:\"yes\";s:14:\"receiver_email\";s:17:\"yao3060@gmail.com\";s:14:\"identity_token\";s:0:\"\";s:14:\"invoice_prefix\";s:3:\"WC-\";s:13:\"send_shipping\";s:3:\"yes\";s:16:\"address_override\";s:2:\"no\";s:13:\"paymentaction\";s:4:\"sale\";s:9:\"image_url\";s:0:\"\";s:11:\"api_details\";s:0:\"\";s:12:\"api_username\";s:0:\"\";s:12:\"api_password\";s:0:\"\";s:13:\"api_signature\";s:0:\"\";s:20:\"sandbox_api_username\";s:0:\"\";s:20:\"sandbox_api_password\";s:0:\"\";s:21:\"sandbox_api_signature\";s:0:\"\";s:12:\"_should_load\";s:2:\"no\";}','yes'),(246,'woocommerce_version','6.9.4','yes'),(247,'woocommerce_db_version','6.9.4','yes'),(248,'woocommerce_admin_install_timestamp','1668845550','yes'),(249,'woocommerce_inbox_variant_assignment','1','yes'),(250,'action_scheduler_lock_async-request-runner','1669624341','yes'),(251,'woocommerce_admin_notices','a:0:{}','yes'),(252,'woocommerce_maxmind_geolocation_settings','a:1:{s:15:\"database_prefix\";s:32:\"kSSpGV41m5aL47sVmMGDdc4bGgNhkIa6\";}','yes'),(253,'widget_woocommerce_widget_cart','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(254,'widget_woocommerce_layered_nav_filters','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(255,'widget_woocommerce_layered_nav','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(256,'widget_woocommerce_price_filter','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(257,'widget_woocommerce_product_categories','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(258,'widget_woocommerce_product_search','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(259,'widget_woocommerce_product_tag_cloud','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(260,'widget_woocommerce_products','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(261,'widget_woocommerce_recently_viewed_products','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(262,'widget_woocommerce_top_rated_products','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(263,'widget_woocommerce_recent_reviews','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(264,'widget_woocommerce_rating_filter','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(265,'wc_blocks_db_schema_version','260','yes'),(266,'wc_remote_inbox_notifications_stored_state','O:8:\"stdClass\":2:{s:22:\"there_were_no_products\";b:1;s:22:\"there_are_now_products\";b:1;}','no'),(267,'woocommerce_task_list_tracked_completed_tasks','a:9:{i:0;s:8:\"purchase\";i:1;s:13:\"store_details\";i:2;s:8:\"shipping\";i:3;s:8:\"products\";i:4;s:8:\"payments\";i:5;s:3:\"tax\";i:6;s:9:\"marketing\";i:7;s:10:\"appearance\";i:8;s:15:\"review-shipping\";}','yes'),(268,'woocommerce_task_list_completed_lists','a:4:{i:0;s:8:\"extended\";i:1;s:19:\"extended_two_column\";i:2;s:5:\"setup\";i:3;s:16:\"setup_two_column\";}','yes'),(269,'woocommerce_onboarding_profile','a:9:{s:18:\"is_agree_marketing\";b:0;s:11:\"store_email\";s:17:\"yao3060@gmail.com\";s:8:\"industry\";a:1:{i:0;a:1:{s:4:\"slug\";s:27:\"fashion-apparel-accessories\";}}s:13:\"product_types\";a:2:{i:0;s:8:\"physical\";i:1;s:9:\"downloads\";}s:13:\"product_count\";s:5:\"1000+\";s:14:\"selling_venues\";s:2:\"no\";s:12:\"setup_client\";b:1;s:5:\"theme\";s:10:\"storefront\";s:9:\"completed\";b:1;}','yes'),(270,'woocommerce_task_list_dismissed_tasks','a:0:{}','yes'),(271,'woocommerce_admin_created_default_shipping_zones','yes','yes'),(272,'current_theme','Storefront','yes'),(273,'theme_switched','','yes'),(274,'theme_mods_storefront','a:3:{s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:11:\"custom_logo\";i:14;}','yes'),(275,'woocommerce_catalog_rows','4','yes'),(276,'woocommerce_catalog_columns','3','yes'),(277,'woocommerce_maybe_regenerate_images_hash','27acde77266b4d2a3491118955cb3f66','yes'),(278,'storefront_nux_fresh_site','0','yes'),(279,'woocommerce_task_list_prompt_shown','1','yes'),(281,'product_cat_children','a:1:{i:16;a:1:{i:0;i:17;}}','yes'),(282,'pa_color_children','a:0:{}','yes'),(283,'WPLANG','','yes'),(284,'new_admin_email','yao3060@gmail.com','yes'),(285,'woocommerce_cod_settings','a:6:{s:7:\"enabled\";s:3:\"yes\";s:5:\"title\";s:16:\"Cash on delivery\";s:11:\"description\";s:28:\"Pay with cash upon delivery.\";s:12:\"instructions\";s:28:\"Pay with cash upon delivery.\";s:18:\"enable_for_methods\";a:0:{}s:18:\"enable_for_virtual\";s:3:\"yes\";}','yes'),(286,'woocommerce_no_sales_tax','1','yes'),(287,'woocommerce_task_list_tracked_completed_actions','a:2:{i:0;s:9:\"marketing\";i:1;s:10:\"appearance\";}','yes'),(288,'woocommerce_onboarding_homepage_post_id','12','yes'),(289,'woocommerce_demo_store_notice','','yes'),(290,'woocommerce_default_homepage_layout','two_columns','yes'),(291,'recovery_mode_email_last_sent','1669342670','yes'),(292,'recovery_keys','a:4:{s:22:\"TpAiAGkMtOcRSli7PKLHbd\";a:2:{s:10:\"hashed_key\";s:34:\"$P$Bny433Vfo8ZDT1eqyqlzofwe3lBGL//\";s:10:\"created_at\";i:1668866065;}s:22:\"ChwKSfYaenA2HtZo0p06zW\";a:2:{s:10:\"hashed_key\";s:34:\"$P$B4T0wcSWKypGvo3BSQM3xakRxgocPY.\";s:10:\"created_at\";i:1669002557;}s:22:\"c5oWJGAJTrwjDKfhzejASP\";a:2:{s:10:\"hashed_key\";s:34:\"$P$B4N2uA5b9b4.3d2xIzCs8ks.62F4u71\";s:10:\"created_at\";i:1669195660;}s:22:\"00rMPdFdEdO18eQWzEHcYv\";a:2:{s:10:\"hashed_key\";s:34:\"$P$BrTOOdldag7Fd0bNlIvAM1NrBo7iVO0\";s:10:\"created_at\";i:1669342670;}}','yes'),(296,'wc_stripe_wh_monitor_began_at','1668939650','yes'),(297,'wc_stripe_wh_last_success_at','0','yes'),(298,'wc_stripe_wh_last_failure_at','0','yes'),(299,'wc_stripe_wh_last_error','validation_succeeded','yes'),(300,'wc_stripe_show_style_notice','no','yes'),(301,'wc_stripe_show_sca_notice','no','yes'),(302,'wc_stripe_version','7.0.1','yes'),(303,'woocommerce_payermax_settings','a:16:{s:7:\"enabled\";s:3:\"yes\";s:5:\"title\";s:8:\"PayerMax\";s:11:\"description\";s:35:\"You will be redirected to PayerMax.\";s:11:\"merchant_id\";s:4:\"XX11\";s:20:\"merchant_private_key\";s:848:\"MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKExZ32j0CdzwZtJixKDHmwk6P6Xe2s1JyEVJ5VYBf7MDs/tD611KH6LnxCf6M3DbIJs2gPx6/nk70H94d7ZR+vDC0Ru7oC3YArGXxjcwkjivGJ4pkjj63+q5MorIm+5/s323y3HE8J81MTNsUK1G6B1mPsn5n6MziKj9Bc9SS4hAgMBAAECgYBb246RX5/IS8QB3VgedZAJqsMICoUvo/unc6m6Bo5sFBdA0GRFweUQsDo2PBpr37jfXm6jHuMN5jOeVLK5zvKXdGoRpkoxdUtYtR51KCWkzUkz6LRH+ooLuC7k3iUVVnZZ7zNLgQORRlFwMCA2gHa3mvbdzW3tP92rgdM3oCDHAQJBAN7jQ0C5eyfymjIRJ/AEJPw+oH7Vr+evFuJRahjViE3es7INpFZDmwBLwuHHLMATwNuQ5kniH02IzXA0h+hborECQQC5I81iab/RYJSY45pxTIusUqJGF4ZQg3ZxdnnNsxbtl0uMw17RArLF/czV3DwwCnGGepp9TNBkIrbglTj7R75xAkEA0jgfEkjes4rJjDdKJ8KA77hRv87jne0x9Ds9ija73FYTvffH6+TPqLPMFw64UmFPIMfFrCGtzH8e5JlnJexnwQJAA3UvuM7QzlBHdjOKBuOvGCDS9wwpbgeGhsf3rmfR3c4dkxtzAeRTAm+jC7t5RExtol1X1U9B9RzQ3ZDr54WHgQJAeicYgZYMymBbxcmlz6+GhvnNQWNh0vJcsKb3YQ/uolMv3ymiglj89QiInTJmvXsU8oEdSv7XE+Pq7Od+MrJ/NA==\";s:7:\"sandbox\";s:2:\"no\";s:5:\"debug\";s:2:\"no\";s:7:\"webhook\";s:29:\"/wp-json/payermax/v1/callback\";s:26:\"enable_for_payment_methods\";a:1:{i:0;s:12:\"cashier_card\";}s:15:\"merchant_number\";s:15:\"010213834784554\";s:12:\"instructions\";s:35:\"You will be redirected to PayerMax.\";s:21:\"enable_for_currencies\";s:0:\"\";s:6:\"app_id\";s:32:\"6666c8b036a24579974497c2f9a33333\";s:28:\"available_for_payment_method\";s:0:\"\";s:24:\"available_for_currencies\";s:0:\"\";s:19:\"merchant_public_key\";s:216:\"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQChMWd9o9Anc8GbSYsSgx5sJOj+l3trNSchFSeVWAX+zA7P7Q+tdSh+i58Qn+jNw2yCbNoD8ev55O9B/eHe2UfrwwtEbu6At2AKxl8Y3MJI4rxieKZI4+t/quTKKyJvuf7N9t8txxPCfNTEzbFCtRugdZj7J+Z+jM4io/QXPUkuIQIDAQAB\";}','yes'),(304,'woocommerce_gateway_order','a:4:{s:4:\"bacs\";i:0;s:6:\"cheque\";i:1;s:3:\"cod\";i:2;s:8:\"payermax\";i:3;}','yes'),(305,'woocommerce_admin_reviewed_default_shipping_zones','yes','yes'),(306,'widget_mailpoet_form','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(307,'woocommerce_task_list_reminder_bar_hidden','yes','yes'),(308,'loco_plugin_config__woocommerce-gateway-payermax/woocommerce-gateway-payermax.php','a:4:{s:1:\"c\";s:23:\"Loco_config_CustomSaved\";s:1:\"v\";i:0;s:1:\"d\";a:3:{i:0;s:6:\"bundle\";i:1;a:1:{s:4:\"name\";s:28:\"WooCommerce PayerMax Gateway\";}i:2;a:1:{i:0;a:3:{i:0;s:6:\"domain\";i:1;a:1:{s:4:\"name\";s:28:\"woocommerce-gateway-payermax\";}i:2;a:1:{i:0;a:3:{i:0;s:7:\"project\";i:1;a:2:{s:4:\"name\";s:28:\"WooCommerce PayerMax Gateway\";s:4:\"slug\";s:28:\"woocommerce-gateway-payermax\";}i:2;a:3:{i:0;a:3:{i:0;s:6:\"source\";i:1;a:0:{}i:2;a:1:{i:0;a:3:{i:0;s:9:\"directory\";i:1;a:0:{}i:2;a:1:{i:0;s:0:\"\";}}}}i:1;a:3:{i:0;s:6:\"target\";i:1;a:0:{}i:2;a:1:{i:0;a:3:{i:0;s:9:\"directory\";i:1;a:0:{}i:2;a:1:{i:0;s:9:\"languages\";}}}}i:2;a:3:{i:0;s:8:\"template\";i:1;a:0:{}i:2;a:1:{i:0;a:3:{i:0;s:4:\"file\";i:1;a:0:{}i:2;a:1:{i:0;s:42:\"languages/woocommerce-gateway-payermax.pot\";}}}}}}}}}}s:1:\"t\";i:1669366728;}','no'),(309,'loco_recent','a:4:{s:1:\"c\";s:21:\"Loco_data_RecentItems\";s:1:\"v\";i:0;s:1:\"d\";a:1:{s:6:\"bundle\";a:1:{s:68:\"plugin.woocommerce-gateway-payermax/woocommerce-gateway-payermax.php\";i:1669366806;}}s:1:\"t\";i:1669366806;}','no');
/*!40000 ALTER TABLE `wp_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=825 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_postmeta`
--

LOCK TABLES `wp_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_postmeta` DISABLE KEYS */;
INSERT INTO `wp_postmeta` VALUES (1,2,'_wp_page_template','default'),(2,3,'_wp_page_template','default'),(3,10,'_wp_attached_file','2022/11/hoodie-with-logo-2.jpg'),(4,10,'_wp_attachment_metadata','a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:30:\"2022/11/hoodie-with-logo-2.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:30:\"hoodie-with-logo-2-324x324.jpg\";s:5:\"width\";i:324;s:6:\"height\";i:324;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-416x416.jpg\";s:5:\"width\";i:416;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),(5,10,'_wc_attachment_source','https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-with-logo-2.jpg'),(6,11,'_regular_price','45'),(7,11,'total_sales','13'),(8,11,'_tax_status','taxable'),(9,11,'_tax_class',''),(10,11,'_manage_stock','no'),(11,11,'_backorders','no'),(12,11,'_sold_individually','no'),(13,11,'_virtual','no'),(14,11,'_downloadable','no'),(15,11,'_download_limit','0'),(16,11,'_download_expiry','0'),(17,11,'_thumbnail_id','10'),(18,11,'_stock',NULL),(19,11,'_stock_status','instock'),(20,11,'_wc_average_rating','0'),(21,11,'_wc_review_count','0'),(22,11,'_product_attributes','a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}'),(23,11,'_product_version','6.9.4'),(24,11,'_price','40'),(25,11,'_wpcom_is_markdown','1'),(26,11,'_edit_lock','1669106254:1'),(27,11,'_edit_last','1'),(28,12,'_wp_page_template','template-fullwidth.php'),(29,14,'_wp_attached_file','2022/11/apple-logo.png'),(30,14,'_wp_attachment_metadata','a:5:{s:5:\"width\";i:512;s:6:\"height\";i:256;s:4:\"file\";s:22:\"2022/11/apple-logo.png\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"apple-logo-300x150.png\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"apple-logo-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:22:\"apple-logo-324x256.png\";s:5:\"width\";i:324;s:6:\"height\";i:256;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:22:\"apple-logo-416x208.png\";s:5:\"width\";i:416;s:6:\"height\";i:208;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:22:\"apple-logo-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),(31,7,'_edit_lock','1668860130:1'),(32,7,'_wp_page_template','template-fullwidth.php'),(33,6,'_edit_last','1'),(34,6,'_wp_page_template','template-fullwidth.php'),(35,6,'_edit_lock','1668860285:1'),(36,8,'_edit_last','1'),(37,8,'_wp_page_template','template-fullwidth.php'),(38,8,'_edit_lock','1668860293:1'),(39,5,'_edit_last','1'),(40,5,'_wp_page_template','default'),(41,5,'_edit_lock','1668860301:1'),(42,19,'_order_key','wc_order_oNfB4e8ocTITI'),(43,19,'_customer_user','1'),(44,19,'_payment_method','cod'),(45,19,'_payment_method_title','Cash on delivery'),(46,19,'_customer_ip_address','172.20.0.1'),(47,19,'_customer_user_agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'),(48,19,'_created_via','checkout'),(49,19,'_cart_hash','6e0e990b73ec17e814a03c650e986521'),(50,19,'_billing_first_name','YAO'),(51,19,'_billing_last_name','YINGYING'),(52,19,'_billing_address_1','襄阳南路489号4F'),(53,19,'_billing_address_2','金环大厦'),(54,19,'_billing_city','徐汇区'),(55,19,'_billing_state','CN10'),(56,19,'_billing_postcode','1111'),(57,19,'_billing_country','CN'),(58,19,'_billing_email','yao3060@gmail.com'),(59,19,'_billing_phone','18601660362'),(60,19,'_shipping_first_name','YAO'),(61,19,'_shipping_last_name','YINGYING'),(62,19,'_shipping_address_1','襄阳南路489号4F'),(63,19,'_shipping_address_2','金环大厦'),(64,19,'_shipping_city','徐汇区'),(65,19,'_shipping_state','CN10'),(66,19,'_shipping_postcode','1111'),(67,19,'_shipping_country','CN'),(68,19,'_order_currency','CNY'),(69,19,'_cart_discount','0'),(70,19,'_cart_discount_tax','0'),(71,19,'_order_shipping','0'),(72,19,'_order_shipping_tax','0'),(73,19,'_order_tax','0'),(74,19,'_order_total','45.00'),(75,19,'_order_version','6.9.4'),(76,19,'_prices_include_tax','no'),(77,19,'_billing_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 CN10 1111 CN yao3060@gmail.com 18601660362'),(78,19,'_shipping_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 CN10 1111 CN '),(81,19,'_edit_lock','1669020698:1'),(83,19,'is_vat_exempt','no'),(84,19,'_download_permissions_granted','yes'),(85,19,'_recorded_sales','yes'),(86,19,'_recorded_coupon_usage_counts','yes'),(87,19,'_order_stock_reduced','yes'),(88,19,'_new_order_email_sent','true'),(89,20,'_order_key','wc_order_TYm74Dna3B5BC'),(90,20,'_customer_user','1'),(91,20,'_payment_method','payermax'),(92,20,'_payment_method_title','PayerMax'),(93,20,'_customer_ip_address','172.20.0.1'),(94,20,'_customer_user_agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'),(95,20,'_created_via','checkout'),(96,20,'_cart_hash','82a55cdd46c7228ae01eb310dbca553a'),(97,20,'_billing_first_name','YAO'),(98,20,'_billing_last_name','YINGYING'),(99,20,'_billing_address_1','襄阳南路489号4F'),(100,20,'_billing_address_2','金环大厦'),(101,20,'_billing_city','徐汇区'),(102,20,'_billing_state','CN10'),(103,20,'_billing_postcode','1111'),(104,20,'_billing_country','CN'),(105,20,'_billing_email','yao3060@gmail.com'),(106,20,'_billing_phone','18601660362'),(107,20,'_shipping_first_name','YAO'),(108,20,'_shipping_last_name','YINGYING'),(109,20,'_shipping_address_1','襄阳南路489号4F'),(110,20,'_shipping_address_2','金环大厦'),(111,20,'_shipping_city','徐汇区'),(112,20,'_shipping_state','CN10'),(113,20,'_shipping_postcode','1111'),(114,20,'_shipping_country','CN'),(115,20,'_order_currency','CNY'),(116,20,'_cart_discount','0'),(117,20,'_cart_discount_tax','0'),(118,20,'_order_shipping','0'),(119,20,'_order_shipping_tax','0'),(120,20,'_order_tax','0'),(121,20,'_order_total','90.00'),(122,20,'_order_version','6.9.4'),(123,20,'_prices_include_tax','no'),(124,20,'_billing_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 CN10 1111 CN yao3060@gmail.com 18601660362'),(125,20,'_shipping_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 CN10 1111 CN '),(127,20,'_transaction_id','2022112208144620'),(130,20,'is_vat_exempt','no'),(131,11,'_sale_price','40'),(132,21,'_order_key','wc_order_dqgdoVtU5JNRh'),(133,21,'_customer_user','1'),(134,21,'_payment_method','cod'),(135,21,'_payment_method_title','Cash on delivery'),(136,21,'_customer_ip_address','172.20.0.1'),(137,21,'_customer_user_agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'),(138,21,'_created_via','checkout'),(139,21,'_cart_hash','a16ca5afe703e2d286b803606dfcc0fb'),(140,21,'_billing_first_name','YAO'),(141,21,'_billing_last_name','YINGYING'),(142,21,'_billing_address_1','襄阳南路489号4F'),(143,21,'_billing_address_2','金环大厦'),(144,21,'_billing_city','徐汇区'),(145,21,'_billing_state','CN10'),(146,21,'_billing_postcode','1111'),(147,21,'_billing_country','CN'),(148,21,'_billing_email','yao3060@gmail.com'),(149,21,'_billing_phone','18601660362'),(150,21,'_shipping_first_name','YAO'),(151,21,'_shipping_last_name','YINGYING'),(152,21,'_shipping_address_1','襄阳南路489号4F'),(153,21,'_shipping_address_2','金环大厦'),(154,21,'_shipping_city','徐汇区'),(155,21,'_shipping_state','CN10'),(156,21,'_shipping_postcode','1111'),(157,21,'_shipping_country','CN'),(158,21,'_order_currency','CNY'),(159,21,'_cart_discount','0'),(160,21,'_cart_discount_tax','0'),(161,21,'_order_shipping','0'),(162,21,'_order_shipping_tax','0'),(163,21,'_order_tax','0'),(164,21,'_order_total','80.00'),(165,21,'_order_version','6.9.4'),(166,21,'_prices_include_tax','no'),(167,21,'_billing_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 CN10 1111 CN yao3060@gmail.com 18601660362'),(168,21,'_shipping_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 CN10 1111 CN '),(170,21,'_transaction_id','2022112208183521'),(179,21,'is_vat_exempt','no'),(180,21,'_download_permissions_granted','yes'),(181,21,'_recorded_sales','yes'),(182,21,'_recorded_coupon_usage_counts','yes'),(183,21,'_order_stock_reduced','yes'),(184,21,'_new_order_email_sent','true'),(185,22,'_order_key','wc_order_GrElJMIGp9HDc'),(186,22,'_customer_user','1'),(187,22,'_payment_method','cod'),(188,22,'_payment_method_title','Cash on delivery'),(189,22,'_customer_ip_address','172.20.0.1'),(190,22,'_customer_user_agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'),(191,22,'_created_via','checkout'),(192,22,'_cart_hash','7dbb8e7aa60e49209f0919f31719c260'),(193,22,'_billing_first_name','YAO'),(194,22,'_billing_last_name','YINGYING'),(195,22,'_billing_address_1','襄阳南路489号4F'),(196,22,'_billing_address_2','金环大厦'),(197,22,'_billing_city','徐汇区'),(198,22,'_billing_state','CN10'),(199,22,'_billing_postcode','1111'),(200,22,'_billing_country','CN'),(201,22,'_billing_email','yao3060@gmail.com'),(202,22,'_billing_phone','18601660362'),(203,22,'_shipping_first_name','YAO'),(204,22,'_shipping_last_name','YINGYING'),(205,22,'_shipping_address_1','襄阳南路489号4F'),(206,22,'_shipping_address_2','金环大厦'),(207,22,'_shipping_city','徐汇区'),(208,22,'_shipping_state','CN10'),(209,22,'_shipping_postcode','1111'),(210,22,'_shipping_country','CN'),(211,22,'_order_currency','CNY'),(212,22,'_cart_discount','0'),(213,22,'_cart_discount_tax','0'),(214,22,'_order_shipping','0'),(215,22,'_order_shipping_tax','0'),(216,22,'_order_tax','0'),(217,22,'_order_total','40.00'),(218,22,'_order_version','6.9.4'),(219,22,'_prices_include_tax','no'),(220,22,'_billing_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 CN10 1111 CN yao3060@gmail.com 18601660362'),(221,22,'_shipping_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 CN10 1111 CN '),(223,22,'_transaction_id','2022112210330622'),(226,22,'is_vat_exempt','no'),(227,22,'_download_permissions_granted','yes'),(228,22,'_recorded_sales','yes'),(229,22,'_recorded_coupon_usage_counts','yes'),(230,22,'_order_stock_reduced','yes'),(231,22,'_new_order_email_sent','true'),(232,23,'_order_key','wc_order_cfZx1viMHGlbN'),(233,23,'_customer_user','1'),(234,23,'_payment_method','payermax'),(235,23,'_payment_method_title','PayerMax'),(236,23,'_customer_ip_address','172.20.0.1'),(237,23,'_customer_user_agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'),(238,23,'_created_via','checkout'),(239,23,'_cart_hash','7dbb8e7aa60e49209f0919f31719c260'),(240,23,'_billing_first_name','YAO'),(241,23,'_billing_last_name','YINGYING'),(242,23,'_billing_address_1','襄阳南路489号4F'),(243,23,'_billing_address_2','金环大厦'),(244,23,'_billing_city','徐汇区'),(245,23,'_billing_state','HONG KONG'),(246,23,'_billing_postcode','1111'),(247,23,'_billing_country','HK'),(248,23,'_billing_email','yao3060@gmail.com'),(249,23,'_billing_phone','18601660362'),(250,23,'_shipping_first_name','YAO'),(251,23,'_shipping_last_name','YINGYING'),(252,23,'_shipping_address_1','襄阳南路489号4F'),(253,23,'_shipping_address_2','金环大厦'),(254,23,'_shipping_city','徐汇区'),(255,23,'_shipping_state','HONG KONG'),(256,23,'_shipping_postcode','1111'),(257,23,'_shipping_country','HK'),(258,23,'_order_currency','USD'),(259,23,'_cart_discount','0'),(260,23,'_cart_discount_tax','0'),(261,23,'_order_shipping','0'),(262,23,'_order_shipping_tax','0'),(263,23,'_order_tax','0'),(264,23,'_order_total','40.00'),(265,23,'_order_version','6.9.4'),(266,23,'_prices_include_tax','no'),(267,23,'_billing_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK yao3060@gmail.com 18601660362'),(268,23,'_shipping_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK '),(270,23,'_transaction_id','2022112807180423'),(273,23,'is_vat_exempt','no'),(274,22,'_edit_lock','1669186324:1'),(275,21,'_edit_lock','1669185852:1'),(276,24,'_order_currency','CNY'),(277,24,'_cart_discount','0'),(278,24,'_cart_discount_tax','0'),(279,24,'_order_shipping','0'),(280,24,'_order_shipping_tax','0'),(281,24,'_order_tax','0'),(282,24,'_order_total','-10.00'),(283,24,'_order_version','6.9.4'),(284,24,'_prices_include_tax','no'),(285,24,'_refund_amount','10.00'),(286,24,'_refunded_by','1'),(287,24,'_refunded_payment',''),(288,24,'_refund_reason',''),(289,25,'_order_currency','CNY'),(290,25,'_cart_discount','0'),(291,25,'_cart_discount_tax','0'),(292,25,'_order_shipping','0'),(293,25,'_order_shipping_tax','0'),(294,25,'_order_tax','0'),(295,25,'_order_total','-20.00'),(296,25,'_order_version','6.9.4'),(297,25,'_prices_include_tax','no'),(298,25,'_refund_amount','20.00'),(299,25,'_refunded_by','1'),(300,25,'_refunded_payment',''),(301,25,'_refund_reason',''),(302,26,'_order_currency','CNY'),(303,26,'_cart_discount','0'),(304,26,'_cart_discount_tax','0'),(305,26,'_order_shipping','0'),(306,26,'_order_shipping_tax','0'),(307,26,'_order_tax','0'),(308,26,'_order_total','-50.00'),(309,26,'_order_version','6.9.4'),(310,26,'_prices_include_tax','no'),(311,26,'_refund_amount','50.00'),(312,26,'_refunded_by','1'),(313,26,'_refunded_payment',''),(314,26,'_refund_reason',''),(315,27,'_order_currency','CNY'),(316,27,'_cart_discount','0'),(317,27,'_cart_discount_tax','0'),(318,27,'_order_shipping','0'),(319,27,'_order_shipping_tax','0'),(320,27,'_order_tax','0'),(321,27,'_order_total','-10.00'),(322,27,'_order_version','6.9.4'),(323,27,'_prices_include_tax','no'),(324,27,'_refund_amount','10.00'),(325,27,'_refunded_by','1'),(326,27,'_refunded_payment',''),(327,27,'_refund_reason',''),(328,22,'_edit_last','1'),(329,22,'_date_completed','1669174632'),(330,22,'_date_paid','1669174632'),(331,22,'_paid_date','2022-11-23 11:37:12'),(332,22,'_completed_date','2022-11-23 11:37:12'),(333,28,'_order_currency','CNY'),(334,28,'_cart_discount','0'),(335,28,'_cart_discount_tax','0'),(336,28,'_order_shipping','0'),(337,28,'_order_shipping_tax','0'),(338,28,'_order_tax','0'),(339,28,'_order_total','-20.00'),(340,28,'_order_version','6.9.4'),(341,28,'_prices_include_tax','no'),(342,28,'_refund_amount','20.00'),(343,28,'_refunded_by','1'),(344,28,'_refunded_payment',''),(345,28,'_refund_reason',''),(346,29,'_order_currency','CNY'),(347,29,'_cart_discount','0'),(348,29,'_cart_discount_tax','0'),(349,29,'_order_shipping','0'),(350,29,'_order_shipping_tax','0'),(351,29,'_order_tax','0'),(352,29,'_order_total','-10.00'),(353,29,'_order_version','6.9.4'),(354,29,'_prices_include_tax','no'),(355,29,'_refund_amount','10.00'),(356,29,'_refunded_by','1'),(357,29,'_refunded_payment',''),(358,29,'_refund_reason',''),(359,31,'_order_key','wc_order_uYy0Vje20paIM'),(360,31,'_customer_user','1'),(361,31,'_payment_method','payermax'),(362,31,'_payment_method_title','PayerMax'),(363,31,'_customer_ip_address','172.20.0.1'),(364,31,'_customer_user_agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'),(365,31,'_created_via','checkout'),(366,31,'_cart_hash','7dbb8e7aa60e49209f0919f31719c260'),(367,31,'_billing_first_name','YAO'),(368,31,'_billing_last_name','YINGYING'),(369,31,'_billing_address_1','襄阳南路489号4F'),(370,31,'_billing_address_2','金环大厦'),(371,31,'_billing_city','徐汇区'),(372,31,'_billing_state','HONG KONG'),(373,31,'_billing_postcode','1111'),(374,31,'_billing_country','HK'),(375,31,'_billing_email','yao3060@gmail.com'),(376,31,'_billing_phone','18601660362'),(377,31,'_shipping_first_name','YAO'),(378,31,'_shipping_last_name','YINGYING'),(379,31,'_shipping_address_1','襄阳南路489号4F'),(380,31,'_shipping_address_2','金环大厦'),(381,31,'_shipping_city','徐汇区'),(382,31,'_shipping_state','HONG KONG'),(383,31,'_shipping_postcode','1111'),(384,31,'_shipping_country','HK'),(385,31,'_order_currency','USD'),(386,31,'_cart_discount','0'),(387,31,'_cart_discount_tax','0'),(388,31,'_order_shipping','0'),(389,31,'_order_shipping_tax','0'),(390,31,'_order_tax','0'),(391,31,'_order_total','40.00'),(392,31,'_order_version','6.9.4'),(393,31,'_prices_include_tax','no'),(394,31,'_billing_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK yao3060@gmail.com 18601660362'),(395,31,'_shipping_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK '),(396,31,'is_vat_exempt','no'),(397,31,'_transaction_id','2022112412303731'),(398,31,'_recorded_sales','yes'),(399,31,'_recorded_coupon_usage_counts','yes'),(400,31,'_order_stock_reduced','yes'),(401,31,'_new_order_email_sent','true'),(402,31,'_edit_lock','1669341930:1'),(403,31,'_date_paid','1669342031'),(404,31,'_paid_date','2022-11-25 10:07:11'),(405,31,'_download_permissions_granted','yes'),(406,32,'_order_key','wc_order_SscYXCW0u0c0l'),(407,32,'_customer_user','1'),(408,32,'_payment_method','payermax'),(409,32,'_payment_method_title','PayerMax'),(410,32,'_customer_ip_address','172.20.0.1'),(411,32,'_customer_user_agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'),(412,32,'_created_via','checkout'),(413,32,'_cart_hash','7dbb8e7aa60e49209f0919f31719c260'),(414,32,'_billing_first_name','YAO'),(415,32,'_billing_last_name','YINGYING'),(416,32,'_billing_address_1','襄阳南路489号4F'),(417,32,'_billing_address_2','金环大厦'),(418,32,'_billing_city','徐汇区'),(419,32,'_billing_state','HONG KONG'),(420,32,'_billing_postcode','1111'),(421,32,'_billing_country','HK'),(422,32,'_billing_email','yao3060@gmail.com'),(423,32,'_billing_phone','18601660362'),(424,32,'_shipping_first_name','YAO'),(425,32,'_shipping_last_name','YINGYING'),(426,32,'_shipping_address_1','襄阳南路489号4F'),(427,32,'_shipping_address_2','金环大厦'),(428,32,'_shipping_city','徐汇区'),(429,32,'_shipping_state','HONG KONG'),(430,32,'_shipping_postcode','1111'),(431,32,'_shipping_country','HK'),(432,32,'_order_currency','USD'),(433,32,'_cart_discount','0'),(434,32,'_cart_discount_tax','0'),(435,32,'_order_shipping','0'),(436,32,'_order_shipping_tax','0'),(437,32,'_order_tax','0'),(438,32,'_order_total','40.00'),(439,32,'_order_version','6.9.4'),(440,32,'_prices_include_tax','no'),(441,32,'_billing_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK yao3060@gmail.com 18601660362'),(442,32,'_shipping_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK '),(443,32,'is_vat_exempt','no'),(444,32,'_recorded_sales','yes'),(445,32,'_recorded_coupon_usage_counts','yes'),(446,32,'_order_stock_reduced','yes'),(447,32,'_new_order_email_sent','true'),(448,32,'_transaction_id','2022112502552332'),(449,32,'_date_paid','1669344962'),(450,32,'_paid_date','2022-11-25 10:56:02'),(451,32,'_download_permissions_granted','yes'),(452,32,'_edit_lock','1669365026:1'),(596,44,'_order_currency','USD'),(597,44,'_cart_discount','0'),(598,44,'_cart_discount_tax','0'),(599,44,'_order_shipping','0'),(600,44,'_order_shipping_tax','0'),(601,44,'_order_tax','0'),(602,44,'_order_total','-1.00'),(603,44,'_order_version','6.9.4'),(604,44,'_prices_include_tax','no'),(605,44,'_refund_amount','1.00'),(606,44,'_refunded_by','1'),(607,44,'_refunded_payment','1'),(608,44,'_refund_reason','test'),(609,45,'_order_currency','USD'),(610,45,'_cart_discount','0'),(611,45,'_cart_discount_tax','0'),(612,45,'_order_shipping','0'),(613,45,'_order_shipping_tax','0'),(614,45,'_order_tax','0'),(615,45,'_order_total','-1.00'),(616,45,'_order_version','6.9.4'),(617,45,'_prices_include_tax','no'),(618,45,'_refund_amount','1.00'),(619,45,'_refunded_by','1'),(620,45,'_refunded_payment','1'),(621,45,'_refund_reason','131313'),(622,46,'_order_key','wc_order_xdbnW94czy5Us'),(623,46,'_customer_user','1'),(624,46,'_payment_method','payermax'),(625,46,'_payment_method_title','PayerMax'),(626,46,'_customer_ip_address','172.20.0.1'),(627,46,'_customer_user_agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'),(628,46,'_created_via','checkout'),(629,46,'_cart_hash','7dbb8e7aa60e49209f0919f31719c260'),(630,46,'_billing_first_name','YAO'),(631,46,'_billing_last_name','YINGYING'),(632,46,'_billing_address_1','襄阳南路489号4F'),(633,46,'_billing_address_2','金环大厦'),(634,46,'_billing_city','徐汇区'),(635,46,'_billing_state','HONG KONG'),(636,46,'_billing_postcode','1111'),(637,46,'_billing_country','HK'),(638,46,'_billing_email','yao3060@gmail.com'),(639,46,'_billing_phone','18601660362'),(640,46,'_shipping_first_name','YAO'),(641,46,'_shipping_last_name','YINGYING'),(642,46,'_shipping_address_1','襄阳南路489号4F'),(643,46,'_shipping_address_2','金环大厦'),(644,46,'_shipping_city','徐汇区'),(645,46,'_shipping_state','HONG KONG'),(646,46,'_shipping_postcode','1111'),(647,46,'_shipping_country','HK'),(648,46,'_order_currency','USD'),(649,46,'_cart_discount','0'),(650,46,'_cart_discount_tax','0'),(651,46,'_order_shipping','0'),(652,46,'_order_shipping_tax','0'),(653,46,'_order_tax','0'),(654,46,'_order_total','40.00'),(655,46,'_order_version','6.9.4'),(656,46,'_prices_include_tax','no'),(657,46,'_billing_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK yao3060@gmail.com 18601660362'),(658,46,'_shipping_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK '),(659,46,'is_vat_exempt','no'),(660,46,'_recorded_sales','yes'),(661,46,'_recorded_coupon_usage_counts','yes'),(662,46,'_order_stock_reduced','yes'),(663,46,'_new_order_email_sent','true'),(664,46,'_transaction_id','2022112510215346'),(665,46,'_date_paid','1669371759'),(666,46,'_paid_date','2022-11-25 18:22:39'),(667,46,'_download_permissions_granted','yes'),(668,46,'_edit_lock','1669371799:1'),(669,47,'_order_key','wc_order_hwfEvR9LNF0xc'),(670,47,'_customer_user','1'),(671,47,'_payment_method','payermax'),(672,47,'_payment_method_title','PayerMax'),(673,47,'_customer_ip_address','172.20.0.1'),(674,47,'_customer_user_agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'),(675,47,'_created_via','checkout'),(676,47,'_cart_hash','7dbb8e7aa60e49209f0919f31719c260'),(677,47,'_billing_first_name','YAO'),(678,47,'_billing_last_name','YINGYING'),(679,47,'_billing_address_1','襄阳南路489号4F'),(680,47,'_billing_address_2','金环大厦'),(681,47,'_billing_city','徐汇区'),(682,47,'_billing_state','HONG KONG'),(683,47,'_billing_postcode','1111'),(684,47,'_billing_country','HK'),(685,47,'_billing_email','yao3060@gmail.com'),(686,47,'_billing_phone','18601660362'),(687,47,'_shipping_first_name','YAO'),(688,47,'_shipping_last_name','YINGYING'),(689,47,'_shipping_address_1','襄阳南路489号4F'),(690,47,'_shipping_address_2','金环大厦'),(691,47,'_shipping_city','徐汇区'),(692,47,'_shipping_state','HONG KONG'),(693,47,'_shipping_postcode','1111'),(694,47,'_shipping_country','HK'),(695,47,'_order_currency','USD'),(696,47,'_cart_discount','0'),(697,47,'_cart_discount_tax','0'),(698,47,'_order_shipping','0'),(699,47,'_order_shipping_tax','0'),(700,47,'_order_tax','0'),(701,47,'_order_total','40.00'),(702,47,'_order_version','6.9.4'),(703,47,'_prices_include_tax','no'),(704,47,'_billing_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK yao3060@gmail.com 18601660362'),(705,47,'_shipping_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK '),(706,47,'is_vat_exempt','no'),(707,47,'_recorded_sales','yes'),(708,47,'_recorded_coupon_usage_counts','yes'),(709,47,'_order_stock_reduced','yes'),(710,47,'_new_order_email_sent','true'),(711,47,'_transaction_id','2022112511393947'),(712,47,'_date_paid','1669376403'),(713,47,'_paid_date','2022-11-25 19:40:03'),(714,47,'_download_permissions_granted','yes'),(715,47,'_edit_lock','1669619629:1'),(716,48,'_order_currency','USD'),(717,48,'_cart_discount','0'),(718,48,'_cart_discount_tax','0'),(719,48,'_order_shipping','0'),(720,48,'_order_shipping_tax','0'),(721,48,'_order_tax','0'),(722,48,'_order_total','-1.00'),(723,48,'_order_version','6.9.4'),(724,48,'_prices_include_tax','no'),(725,48,'_refund_amount','1.00'),(726,48,'_refunded_by','1'),(727,48,'_refunded_payment','1'),(728,48,'_refund_reason','test'),(729,23,'_edit_lock','1669620251:1'),(730,23,'_edit_last','1'),(731,23,'_recorded_sales','yes'),(732,23,'_recorded_coupon_usage_counts','yes'),(733,23,'_order_stock_reduced','yes'),(734,23,'_new_order_email_sent','true'),(735,23,'_date_paid','1669620188'),(736,23,'_paid_date','2022-11-28 15:23:08'),(737,23,'_download_permissions_granted','yes'),(738,49,'_order_key','wc_order_iZWPevrRryIMV'),(739,49,'_customer_user','1'),(740,49,'_payment_method','payermax'),(741,49,'_payment_method_title','PayerMax'),(742,49,'_customer_ip_address','172.20.0.1'),(743,49,'_customer_user_agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'),(744,49,'_created_via','checkout'),(745,49,'_cart_hash','ca9bccc937edf2c66fb1b95095a08a66'),(746,49,'_billing_first_name','YAO'),(747,49,'_billing_last_name','YINGYING'),(748,49,'_billing_address_1','襄阳南路489号4F'),(749,49,'_billing_address_2','金环大厦'),(750,49,'_billing_city','徐汇区'),(751,49,'_billing_state','HONG KONG'),(752,49,'_billing_postcode','1111'),(753,49,'_billing_country','HK'),(754,49,'_billing_email','yao3060@gmail.com'),(755,49,'_billing_phone','18601660362'),(756,49,'_shipping_first_name','YAO'),(757,49,'_shipping_last_name','YINGYING'),(758,49,'_shipping_address_1','襄阳南路489号4F'),(759,49,'_shipping_address_2','金环大厦'),(760,49,'_shipping_city','徐汇区'),(761,49,'_shipping_state','HONG KONG'),(762,49,'_shipping_postcode','1111'),(763,49,'_shipping_country','HK'),(764,49,'_order_currency','USD'),(765,49,'_cart_discount','0'),(766,49,'_cart_discount_tax','0'),(767,49,'_order_shipping','0'),(768,49,'_order_shipping_tax','0'),(769,49,'_order_tax','0'),(770,49,'_order_total','120.00'),(771,49,'_order_version','6.9.4'),(772,49,'_prices_include_tax','no'),(773,49,'_billing_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK yao3060@gmail.com 18601660362'),(774,49,'_shipping_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK '),(775,49,'is_vat_exempt','no'),(776,49,'_recorded_sales','yes'),(777,49,'_recorded_coupon_usage_counts','yes'),(778,49,'_order_stock_reduced','yes'),(779,49,'_new_order_email_sent','true'),(780,49,'_transaction_id','2022112807255849'),(781,49,'_edit_lock','1669624163:1'),(782,50,'_order_key','wc_order_kR6tatgoWdLnV'),(783,50,'_customer_user','1'),(784,50,'_payment_method','payermax'),(785,50,'_payment_method_title','PayerMax'),(786,50,'_customer_ip_address','172.20.0.1'),(787,50,'_customer_user_agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'),(788,50,'_created_via','checkout'),(789,50,'_cart_hash','7dbb8e7aa60e49209f0919f31719c260'),(790,50,'_billing_first_name','YAO'),(791,50,'_billing_last_name','YINGYING'),(792,50,'_billing_address_1','襄阳南路489号4F'),(793,50,'_billing_address_2','金环大厦'),(794,50,'_billing_city','徐汇区'),(795,50,'_billing_state','HONG KONG'),(796,50,'_billing_postcode','1111'),(797,50,'_billing_country','HK'),(798,50,'_billing_email','yao3060@gmail.com'),(799,50,'_billing_phone','18601660362'),(800,50,'_shipping_first_name','YAO'),(801,50,'_shipping_last_name','YINGYING'),(802,50,'_shipping_address_1','襄阳南路489号4F'),(803,50,'_shipping_address_2','金环大厦'),(804,50,'_shipping_city','徐汇区'),(805,50,'_shipping_state','HONG KONG'),(806,50,'_shipping_postcode','1111'),(807,50,'_shipping_country','HK'),(808,50,'_order_currency','USD'),(809,50,'_cart_discount','0'),(810,50,'_cart_discount_tax','0'),(811,50,'_order_shipping','0'),(812,50,'_order_shipping_tax','0'),(813,50,'_order_tax','0'),(814,50,'_order_total','40.00'),(815,50,'_order_version','6.9.4'),(816,50,'_prices_include_tax','no'),(817,50,'_billing_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK yao3060@gmail.com 18601660362'),(818,50,'_shipping_address_index','YAO YINGYING  襄阳南路489号4F 金环大厦 徐汇区 HONG KONG 1111 HK '),(819,50,'is_vat_exempt','no'),(820,50,'_recorded_sales','yes'),(821,50,'_recorded_coupon_usage_counts','yes'),(822,50,'_order_stock_reduced','yes'),(823,50,'_new_order_email_sent','true'),(824,50,'_transaction_id','2022112808322350');
/*!40000 ALTER TABLE `wp_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_posts` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_posts`
--

LOCK TABLES `wp_posts` WRITE;
/*!40000 ALTER TABLE `wp_posts` DISABLE KEYS */;
INSERT INTO `wp_posts` VALUES (1,1,'2022-11-19 06:24:19','2022-11-19 06:24:19','<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->','Hello world!','','publish','open','open','','hello-world','','','2022-11-19 06:24:19','2022-11-19 06:24:19','',0,'http://localhost:8080/?p=1',0,'post','',1),(2,1,'2022-11-19 06:24:19','2022-11-19 06:24:19','<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost:8080/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->','Sample Page','','publish','closed','open','','sample-page','','','2022-11-19 06:24:19','2022-11-19 06:24:19','',0,'http://localhost:8080/?page_id=2',0,'page','',0),(3,1,'2022-11-19 06:24:19','2022-11-19 06:24:19','<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://localhost:8080.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->','Privacy Policy','','draft','closed','open','','privacy-policy','','','2022-11-19 06:24:19','2022-11-19 06:24:19','',0,'http://localhost:8080/?page_id=3',0,'page','',0),(4,1,'2022-11-19 06:25:23','0000-00-00 00:00:00','','Auto Draft','','auto-draft','open','open','','','','','2022-11-19 06:25:23','0000-00-00 00:00:00','',0,'http://localhost:8080/?p=4',0,'post','',0),(5,1,'2022-11-19 08:12:30','2022-11-19 00:12:30','','Shop','','publish','closed','closed','','shop','','','2022-11-19 20:18:21','2022-11-19 12:18:21','',0,'http://localhost:8000/?page_id=5',0,'page','',0),(6,1,'2022-11-19 08:12:30','2022-11-19 00:12:30','<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->','Cart','','publish','closed','closed','','cart','','','2022-11-19 20:18:05','2022-11-19 12:18:05','',0,'http://localhost:8000/?page_id=6',0,'page','',0),(7,1,'2022-11-19 08:12:30','2022-11-19 08:12:30','<!-- wp:shortcode -->\n[woocommerce_checkout]\n<!-- /wp:shortcode -->','Checkout','','publish','closed','closed','','checkout','','','2022-11-19 20:17:51','2022-11-19 12:17:51','',0,'http://localhost:8000/?page_id=7',0,'page','',0),(8,1,'2022-11-19 08:12:30','2022-11-19 00:12:30','<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->','My account','','publish','closed','closed','','my-account','','','2022-11-19 20:18:13','2022-11-19 12:18:13','',0,'http://localhost:8000/?page_id=8',0,'page','',0),(9,1,'2022-11-19 08:12:30','0000-00-00 00:00:00','<!-- wp:paragraph -->\n<p><b>This is a sample page.</b></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h3>Overview</h3>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our refund and returns policy lasts 30 days. If 30 days have passed since your purchase, we can’t offer you a full refund or exchange.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Several types of goods are exempt from being returned. Perishable goods such as food, flowers, newspapers or magazines cannot be returned. We also do not accept products that are intimate or sanitary goods, hazardous materials, or flammable liquids or gases.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Additional non-returnable items:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Gift cards</li>\n<li>Downloadable software products</li>\n<li>Some health and personal care items</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>To complete your return, we require a receipt or proof of purchase.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Please do not send your purchase back to the manufacturer.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>There are certain situations where only partial refunds are granted:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Book with obvious signs of use</li>\n<li>CD, DVD, VHS tape, software, video game, cassette tape, or vinyl record that has been opened.</li>\n<li>Any item not in its original condition, is damaged or missing parts for reasons not due to our error.</li>\n<li>Any item that is returned more than 30 days after delivery</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<h2>Refunds</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Late or missing refunds</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you haven’t received a refund yet, first check your bank account again.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Then contact your credit card company, it may take some time before your refund is officially posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Next contact your bank. There is often some processing time before a refund is posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you’ve done all of this and you still have not received your refund yet, please contact us at {email address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Sale items</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Only regular priced items may be refunded. Sale items cannot be refunded.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Exchanges</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We only replace items if they are defective or damaged. If you need to exchange it for the same item, send us an email at {email address} and send your item to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Gifts</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item was marked as a gift when purchased and shipped directly to you, you’ll receive a gift credit for the value of your return. Once the returned item is received, a gift certificate will be mailed to you.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item wasn’t marked as a gift when purchased, or the gift giver had the order shipped to themselves to give to you later, we will send a refund to the gift giver and they will find out about your return.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Shipping returns</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To return your product, you should mail your product to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. If you receive a refund, the cost of return shipping will be deducted from your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Depending on where you live, the time it may take for your exchanged product to reach you may vary.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are returning more expensive items, you may consider using a trackable shipping service or purchasing shipping insurance. We don’t guarantee that we will receive your returned item.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Need help?</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Contact us at {email} for questions related to refunds and returns.</p>\n<!-- /wp:paragraph -->','Refund and Returns Policy','','draft','closed','closed','','refund_returns','','','2022-11-19 08:12:30','0000-00-00 00:00:00','',0,'http://localhost:8000/?page_id=9',0,'page','',0),(10,1,'2022-11-19 08:26:14','2022-11-19 08:26:14','','hoodie-with-logo-2.jpg','','inherit','open','closed','','hoodie-with-logo-2-jpg','','','2022-11-19 08:26:14','2022-11-19 08:26:14','',0,'http://localhost:8000/wp-content/uploads/2022/11/hoodie-with-logo-2.jpg',0,'attachment','image/jpeg',0),(11,1,'2022-11-19 08:26:15','2022-11-19 08:26:15','Hoodie in sweatshirt fabric made from a cotton blend.','Lorem Ipsum','This is a simple product.','publish','open','closed','','hoodie-with-logo','','','2022-11-22 16:18:15','2022-11-22 08:18:15','',0,'http://localhost:8000/?product=hoodie-with-logo',0,'product','',0),(12,1,'2022-11-19 20:09:15','2022-11-19 12:09:15','<!-- wp:cover {\"dimRatio\":0} -->\n		<div class=\"wp-block-cover\"><div class=\"wp-block-cover__inner-container\"><!-- wp:paragraph {\"align\":\"center\",\"placeholder\":\"Write title…\",\"textColor\":\"white\",\"fontSize\":\"large\"} -->\n		<p class=\"has-text-color has-text-align-center has-large-font-size\">Welcome to the store</p>\n		<!-- /wp:paragraph -->\n\n		<!-- wp:paragraph {\"align\":\"center\",\"textColor\":\"white\"} -->\n		<p class=\"has-text-color has-text-align-center\">Write a short welcome message here</p>\n		<!-- /wp:paragraph -->\n\n		<!-- wp:button {\"align\":\"center\"} -->\n		<div class=\"wp-block-button aligncenter\"><a href=\"http://localhost:8000/shop/\" class=\"wp-block-button__link\">Go shopping</a></div>\n		<!-- /wp:button --></div></div>\n		<!-- /wp:cover -->\n		<!-- wp:heading {\"align\":\"center\"} -->\n		<h2 style=\"text-align:center\">New Products</h2>\n		<!-- /wp:heading -->\n\n		<!-- wp:woocommerce/product-new /--> <!-- wp:media-text {\"mediaPosition\":\"right\",} -->\n		<div class=\"wp-block-media-text alignwide has-media-on-the-right\"><figure class=\"wp-block-media-text__media\"></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n		<p class=\"has-large-font-size\"></p>\n		<!-- /wp:paragraph --></div></div>\n		<!-- /wp:media-text --><!-- wp:media-text {} -->\n		<div class=\"wp-block-media-text alignwide\"><figure class=\"wp-block-media-text__media\"></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n		<p class=\"has-large-font-size\"></p>\n		<!-- /wp:paragraph --></div></div>\n		<!-- /wp:media-text --><!-- wp:media-text {\"mediaPosition\":\"right\",} -->\n		<div class=\"wp-block-media-text alignwide has-media-on-the-right\"><figure class=\"wp-block-media-text__media\"></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n		<p class=\"has-large-font-size\"></p>\n		<!-- /wp:paragraph --></div></div>\n		<!-- /wp:media-text -->\n\n		<!-- wp:woocommerce/featured-product /-->','Homepage','','publish','closed','closed','','homepage','','','2022-11-19 20:09:15','2022-11-19 12:09:15','',0,'http://localhost:8000/homepage/',0,'page','',0),(13,1,'2022-11-19 20:09:15','2022-11-19 12:09:15','<!-- wp:cover {\"dimRatio\":0} -->\n		<div class=\"wp-block-cover\"><div class=\"wp-block-cover__inner-container\"><!-- wp:paragraph {\"align\":\"center\",\"placeholder\":\"Write title…\",\"textColor\":\"white\",\"fontSize\":\"large\"} -->\n		<p class=\"has-text-color has-text-align-center has-large-font-size\">Welcome to the store</p>\n		<!-- /wp:paragraph -->\n\n		<!-- wp:paragraph {\"align\":\"center\",\"textColor\":\"white\"} -->\n		<p class=\"has-text-color has-text-align-center\">Write a short welcome message here</p>\n		<!-- /wp:paragraph -->\n\n		<!-- wp:button {\"align\":\"center\"} -->\n		<div class=\"wp-block-button aligncenter\"><a href=\"http://localhost:8000/shop/\" class=\"wp-block-button__link\">Go shopping</a></div>\n		<!-- /wp:button --></div></div>\n		<!-- /wp:cover -->\n		<!-- wp:heading {\"align\":\"center\"} -->\n		<h2 style=\"text-align:center\">New Products</h2>\n		<!-- /wp:heading -->\n\n		<!-- wp:woocommerce/product-new /--> <!-- wp:media-text {\"mediaPosition\":\"right\",} -->\n		<div class=\"wp-block-media-text alignwide has-media-on-the-right\"><figure class=\"wp-block-media-text__media\"></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n		<p class=\"has-large-font-size\"></p>\n		<!-- /wp:paragraph --></div></div>\n		<!-- /wp:media-text --><!-- wp:media-text {} -->\n		<div class=\"wp-block-media-text alignwide\"><figure class=\"wp-block-media-text__media\"></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n		<p class=\"has-large-font-size\"></p>\n		<!-- /wp:paragraph --></div></div>\n		<!-- /wp:media-text --><!-- wp:media-text {\"mediaPosition\":\"right\",} -->\n		<div class=\"wp-block-media-text alignwide has-media-on-the-right\"><figure class=\"wp-block-media-text__media\"></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n		<p class=\"has-large-font-size\"></p>\n		<!-- /wp:paragraph --></div></div>\n		<!-- /wp:media-text -->\n\n		<!-- wp:woocommerce/featured-product /-->','Homepage','','inherit','closed','closed','','12-revision-v1','','','2022-11-19 20:09:15','2022-11-19 12:09:15','',12,'http://localhost:8000/?p=13',0,'revision','',0),(14,1,'2022-11-19 20:10:26','2022-11-19 12:10:26','','apple-logo','','inherit','open','closed','','apple-logo','','','2022-11-19 20:10:26','2022-11-19 12:10:26','',0,'http://localhost:8000/wp-content/uploads/2022/11/apple-logo.png',0,'attachment','image/png',0),(15,1,'2022-11-19 20:17:51','2022-11-19 12:17:51','<!-- wp:shortcode -->\n[woocommerce_checkout]\n<!-- /wp:shortcode -->','Checkout','','inherit','closed','closed','','7-revision-v1','','','2022-11-19 20:17:51','2022-11-19 12:17:51','',7,'http://localhost:8000/?p=15',0,'revision','',0),(16,1,'2022-11-19 20:18:05','2022-11-19 12:18:05','<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->','Cart','','inherit','closed','closed','','6-revision-v1','','','2022-11-19 20:18:05','2022-11-19 12:18:05','',6,'http://localhost:8000/?p=16',0,'revision','',0),(17,1,'2022-11-19 20:18:13','2022-11-19 12:18:13','<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->','My account','','inherit','closed','closed','','8-revision-v1','','','2022-11-19 20:18:13','2022-11-19 12:18:13','',8,'http://localhost:8000/?p=17',0,'revision','',0),(18,1,'2022-11-19 20:18:21','2022-11-19 12:18:21','','Shop','','inherit','closed','closed','','5-revision-v1','','','2022-11-19 20:18:21','2022-11-19 12:18:21','',5,'http://localhost:8000/?p=18',0,'revision','',0),(19,1,'2022-11-21 14:27:25','2022-11-21 06:27:25','','Order &ndash; November 21, 2022 @ 02:27 PM','','wc-processing','open','closed','wc_order_oNfB4e8ocTITI','order-nov-21-2022-0627-am','','','2022-11-22 16:13:58','2022-11-22 08:13:58','',0,'http://localhost:8000/?post_type=shop_order&#038;p=19',0,'shop_order','',1),(20,1,'2022-11-22 16:14:44','2022-11-22 08:14:44','','Order &ndash; November 22, 2022 @ 04:14 PM','','wc-cancelled','open','closed','wc_order_TYm74Dna3B5BC','order-nov-22-2022-0814-am','','','2022-11-22 18:24:57','2022-11-22 10:24:57','',0,'http://localhost:8000/?post_type=shop_order&#038;p=20',0,'shop_order','',2),(21,1,'2022-11-22 16:18:33','2022-11-22 08:18:33','','Order &ndash; 11月 22, 2022 @ 04:18 下午','','wc-refunded','open','closed','wc_order_dqgdoVtU5JNRh','order-nov-22-2022-0818-am','','','2022-11-22 20:54:14','2022-11-22 12:54:14','',0,'http://localhost:8000/?post_type=shop_order&#038;p=21',0,'shop_order','',3),(22,1,'2022-11-22 18:33:04','2022-11-22 10:33:04','','Order &ndash; 11月 22, 2022 @ 06:33 下午','','wc-refunded','closed','closed','wc_order_GrElJMIGp9HDc','order-nov-22-2022-1033-am','','','2022-11-23 11:38:22','2022-11-23 03:38:22','',0,'http://localhost:8000/?post_type=shop_order&#038;p=22',0,'shop_order','',4),(23,1,'2022-11-22 18:53:15','2022-11-22 10:53:15','','Order &ndash; November 22, 2022 @ 06:53 PM','','wc-processing','closed','closed','wc_order_cfZx1viMHGlbN','order-nov-22-2022-1053-am','','','2022-11-28 15:23:08','2022-11-28 07:23:08','',0,'http://localhost:8000/?post_type=shop_order&#038;p=23',0,'shop_order','',6),(24,1,'2022-11-22 20:42:32','2022-11-22 12:42:32','','退款 &ndash; 2022 Nov 22 12:42 PM','','wc-completed','closed','closed','wc_order_4PMJxptQ1KokO','%e9%80%80%e6%ac%be-2022-nov-22-1242-pm','','','2022-11-22 20:42:32','2022-11-22 12:42:32','',21,'http://localhost:8000/?post_type=shop_order_refund&p=24',0,'shop_order_refund','',0),(25,1,'2022-11-22 20:42:56','2022-11-22 12:42:56','','退款 &ndash; 2022 Nov 22 12:42 PM','','wc-completed','closed','closed','wc_order_IhkvX0K5mB1W3','%e9%80%80%e6%ac%be-2022-nov-22-1242-pm-2','','','2022-11-22 20:42:56','2022-11-22 12:42:56','',21,'http://localhost:8000/?post_type=shop_order_refund&p=25',0,'shop_order_refund','',0),(26,1,'2022-11-22 20:54:13','2022-11-22 12:54:13','','退款 &ndash; 2022 Nov 22 12:54 PM','','wc-completed','closed','closed','wc_order_c7lb5HZuk8kQY','%e9%80%80%e6%ac%be-2022-nov-22-1254-pm','','','2022-11-22 20:54:13','2022-11-22 12:54:13','',21,'http://localhost:8000/?post_type=shop_order_refund&p=26',0,'shop_order_refund','',0),(27,1,'2022-11-23 11:36:05','2022-11-23 03:36:05','','退款 &ndash; 2022 Nov 23 03:36 AM','','wc-completed','closed','closed','wc_order_iFtoFxRVp7bXj','%e9%80%80%e6%ac%be-2022-nov-23-0336-am','','','2022-11-23 11:36:05','2022-11-23 03:36:05','',22,'http://localhost:8000/?post_type=shop_order_refund&p=27',0,'shop_order_refund','',0),(28,1,'2022-11-23 11:37:54','2022-11-23 03:37:54','','退款 &ndash; 2022 Nov 23 03:37 AM','','wc-completed','closed','closed','wc_order_LqskACijA5N78','%e9%80%80%e6%ac%be-2022-nov-23-0337-am','','','2022-11-23 11:37:54','2022-11-23 03:37:54','',22,'http://localhost:8000/?post_type=shop_order_refund&p=28',0,'shop_order_refund','',0),(29,1,'2022-11-23 11:38:21','2022-11-23 03:38:21','','退款 &ndash; 2022 Nov 23 03:38 AM','','wc-completed','closed','closed','wc_order_gSQR0Pf2UCLeM','%e9%80%80%e6%ac%be-2022-nov-23-0338-am','','','2022-11-23 11:38:21','2022-11-23 03:38:21','',22,'http://localhost:8000/?post_type=shop_order_refund&p=29',0,'shop_order_refund','',0),(31,1,'2022-11-24 11:29:48','2022-11-24 03:29:48','','Order &ndash; November 24, 2022 @ 11:29 AM','','wc-processing','open','closed','wc_order_uYy0Vje20paIM','order-nov-24-2022-0329-am','','','2022-11-25 10:07:11','2022-11-25 02:07:11','',0,'http://localhost:8000/?post_type=shop_order&#038;p=31',0,'shop_order','',4),(32,1,'2022-11-25 10:55:10','2022-11-25 02:55:10','','Order &ndash; November 25, 2022 @ 10:55 AM','','wc-processing','open','closed','wc_order_SscYXCW0u0c0l','order-nov-25-2022-0255-am','','','2022-11-25 10:56:02','2022-11-25 02:56:02','',0,'http://localhost:8000/?post_type=shop_order&#038;p=32',0,'shop_order','',7),(44,1,'2022-11-25 13:32:39','2022-11-25 05:32:39','','Refund &ndash; Nov 25, 2022 @ 05:32 AM','','wc-completed','closed','closed','wc_order_b9PmV44Zh92U7','refund-nov-25-2022-0532-am','','','2022-11-25 13:32:39','2022-11-25 05:32:39','',32,'http://localhost:8000/?post_type=shop_order_refund&p=44',0,'shop_order_refund','',0),(45,1,'2022-11-25 13:53:37','2022-11-25 05:53:37','','Refund &ndash; Nov 25, 2022 @ 05:53 AM','','wc-completed','closed','closed','wc_order_01JqclqK9KpLb','refund-nov-25-2022-0553-am','','','2022-11-25 13:53:37','2022-11-25 05:53:37','',32,'http://localhost:8000/?post_type=shop_order_refund&p=45',0,'shop_order_refund','',0),(46,1,'2022-11-25 18:21:41','2022-11-25 10:21:41','','Order &ndash; November 25, 2022 @ 06:21 PM','','wc-processing','open','closed','wc_order_xdbnW94czy5Us','order-nov-25-2022-1021-am','','','2022-11-25 18:22:39','2022-11-25 10:22:39','',0,'http://localhost:8000/?post_type=shop_order&#038;p=46',0,'shop_order','',3),(47,1,'2022-11-25 19:39:25','2022-11-25 11:39:25','','Order &ndash; November 25, 2022 @ 07:39 PM','','wc-processing','open','closed','wc_order_hwfEvR9LNF0xc','order-nov-25-2022-1139-am','','','2022-11-25 19:40:03','2022-11-25 11:40:03','',0,'http://localhost:8000/?post_type=shop_order&#038;p=47',0,'shop_order','',4),(48,1,'2022-11-25 19:42:23','2022-11-25 11:42:23','','Refund &ndash; Nov 25, 2022 @ 11:42 AM','','wc-completed','closed','closed','wc_order_Zv0R0So1hi6Ut','refund-nov-25-2022-1142-am','','','2022-11-25 19:42:23','2022-11-25 11:42:23','',47,'http://localhost:8000/?post_type=shop_order_refund&p=48',0,'shop_order_refund','',0),(49,1,'2022-11-28 15:25:46','2022-11-28 07:25:46','','Order &ndash; November 28, 2022 @ 03:25 PM','','wc-failed','open','closed','wc_order_iZWPevrRryIMV','order-nov-28-2022-0725-am','','','2022-11-28 16:13:02','2022-11-28 08:13:02','',0,'http://localhost:8000/?post_type=shop_order&#038;p=49',0,'shop_order','',4),(50,1,'2022-11-28 16:32:11','2022-11-28 08:32:11','','Order &ndash; November 28, 2022 @ 04:32 PM','','wc-on-hold','open','closed','wc_order_kR6tatgoWdLnV','order-nov-28-2022-0832-am','','','2022-11-28 16:32:13','2022-11-28 08:32:13','',0,'http://localhost:8000/?post_type=shop_order&#038;p=50',0,'shop_order','',2);
/*!40000 ALTER TABLE `wp_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_relationships`
--

LOCK TABLES `wp_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_term_relationships` VALUES (1,1,0),(11,2,0),(11,17,0),(11,18,0);
/*!40000 ALTER TABLE `wp_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint unsigned NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_taxonomy`
--

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_term_taxonomy` VALUES (1,1,'category','',0,1),(2,2,'product_type','',0,1),(3,3,'product_type','',0,0),(4,4,'product_type','',0,0),(5,5,'product_type','',0,0),(6,6,'product_visibility','',0,0),(7,7,'product_visibility','',0,0),(8,8,'product_visibility','',0,0),(9,9,'product_visibility','',0,0),(10,10,'product_visibility','',0,0),(11,11,'product_visibility','',0,0),(12,12,'product_visibility','',0,0),(13,13,'product_visibility','',0,0),(14,14,'product_visibility','',0,0),(15,15,'product_cat','',0,0),(16,16,'product_cat','',0,0),(17,17,'product_cat','',16,1),(18,18,'pa_color','',0,1);
/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_termmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_termmeta`
--

LOCK TABLES `wp_termmeta` WRITE;
/*!40000 ALTER TABLE `wp_termmeta` DISABLE KEYS */;
INSERT INTO `wp_termmeta` VALUES (1,17,'product_count_product_cat','1'),(2,16,'product_count_product_cat','1');
/*!40000 ALTER TABLE `wp_termmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_terms` (
  `term_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_terms`
--

LOCK TABLES `wp_terms` WRITE;
/*!40000 ALTER TABLE `wp_terms` DISABLE KEYS */;
INSERT INTO `wp_terms` VALUES (1,'Uncategorized','uncategorized',0),(2,'simple','simple',0),(3,'grouped','grouped',0),(4,'variable','variable',0),(5,'external','external',0),(6,'exclude-from-search','exclude-from-search',0),(7,'exclude-from-catalog','exclude-from-catalog',0),(8,'featured','featured',0),(9,'outofstock','outofstock',0),(10,'rated-1','rated-1',0),(11,'rated-2','rated-2',0),(12,'rated-3','rated-3',0),(13,'rated-4','rated-4',0),(14,'rated-5','rated-5',0),(15,'Uncategorized','uncategorized',0),(16,'Clothing','clothing',0),(17,'Hoodies','hoodies',0),(18,'Blue','blue',0);
/*!40000 ALTER TABLE `wp_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_usermeta`
--

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;
INSERT INTO `wp_usermeta` VALUES (1,1,'nickname','admin'),(2,1,'first_name','YAO'),(3,1,'last_name','YINGYING'),(4,1,'description',''),(5,1,'rich_editing','true'),(6,1,'syntax_highlighting','true'),(7,1,'comment_shortcuts','false'),(8,1,'admin_color','fresh'),(9,1,'use_ssl','0'),(10,1,'show_admin_bar_front','true'),(11,1,'locale','en_US'),(12,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}'),(13,1,'wp_user_level','10'),(14,1,'dismissed_wp_pointers',''),(15,1,'show_welcome_panel','1'),(16,1,'session_tokens','a:1:{s:64:\"a38fbf1d635195c515ceda5b7fd878bed8f97493bf8359d61293671b82d59deb\";a:5:{s:10:\"expiration\";i:1670207298;s:2:\"ip\";s:10:\"172.20.0.1\";s:2:\"ua\";s:117:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36\";s:5:\"login\";i:1668997698;s:4:\"loco\";a:4:{s:1:\"c\";s:17:\"Loco_data_Session\";s:1:\"v\";i:0;s:1:\"d\";a:1:{s:7:\"success\";a:0:{}}s:1:\"t\";i:1669366745;}}}'),(17,1,'wp_dashboard_quick_press_last_post_id','4'),(18,1,'_woocommerce_tracks_anon_id','woo:c0qb+iuVbuGTbW8cIzSpDs0h'),(19,1,'wc_last_active','1669593600'),(20,1,'last_update','1669624331'),(21,1,'woocommerce_admin_task_list_tracked_started_tasks','{\"products\":1,\"payments\":1,\"tax\":1,\"marketing\":3,\"appearance\":1}'),(22,1,'meta-box-order_product','a:3:{s:4:\"side\";s:84:\"submitdiv,postimagediv,woocommerce-product-images,product_catdiv,tagsdiv-product_tag\";s:6:\"normal\";s:55:\"woocommerce-product-data,postcustom,slugdiv,postexcerpt\";s:8:\"advanced\";s:0:\"\";}'),(23,1,'woocommerce_admin_help_panel_highlight_shown','\"yes\"'),(24,1,'wp_user-settings','libraryContent=browse'),(25,1,'wp_user-settings-time','1668859853'),(27,1,'dismissed_no_secure_connection_notice','1'),(29,1,'community-events-location','a:1:{s:2:\"ip\";s:10:\"172.20.0.0\";}'),(31,1,'billing_first_name','YAO'),(32,1,'billing_last_name','YINGYING'),(33,1,'billing_address_1','襄阳南路489号4F'),(34,1,'billing_address_2','金环大厦'),(35,1,'billing_city','徐汇区'),(36,1,'billing_state','HONG KONG'),(37,1,'billing_postcode','1111'),(38,1,'billing_country','HK'),(39,1,'billing_email','yao3060@gmail.com'),(40,1,'billing_phone','18601660362'),(41,1,'shipping_first_name','YAO'),(42,1,'shipping_last_name','YINGYING'),(43,1,'shipping_address_1','襄阳南路489号4F'),(44,1,'shipping_address_2','金环大厦'),(45,1,'shipping_city','徐汇区'),(46,1,'shipping_state','HONG KONG'),(47,1,'shipping_postcode','1111'),(48,1,'shipping_country','HK'),(49,1,'shipping_method','a:1:{i:0;s:15:\"free_shipping:2\";}'),(50,1,'billing_company',''),(51,1,'shipping_company',''),(52,1,'shipping_phone',''),(56,1,'paying_customer','1');
/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_users` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_users`
--

LOCK TABLES `wp_users` WRITE;
/*!40000 ALTER TABLE `wp_users` DISABLE KEYS */;
INSERT INTO `wp_users` VALUES (1,'admin','$P$BdcduwNlxUueWDaFdtWQc8mccCNG1.1','admin','yao3060@gmail.com','http://localhost:8080','2022-11-19 06:24:19','',0,'admin');
/*!40000 ALTER TABLE `wp_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_admin_note_actions`
--

DROP TABLE IF EXISTS `wp_wc_admin_note_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_admin_note_actions` (
  `action_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `query` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `actioned_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonce_action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `nonce_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=746 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_admin_note_actions`
--

LOCK TABLES `wp_wc_admin_note_actions` WRITE;
/*!40000 ALTER TABLE `wp_wc_admin_note_actions` DISABLE KEYS */;
INSERT INTO `wp_wc_admin_note_actions` VALUES (1,1,'notify-refund-returns-page','Edit page','http://localhost:8000/wp-admin/post.php?post=9&action=edit','actioned','',NULL,NULL),(2,2,'connect','Connect','?page=wc-addons&section=helper','unactioned','',NULL,NULL),(3,3,'install-jp-and-wcs-plugins','Install plugins','','actioned','',NULL,NULL),(82,37,'customize-store-with-storefront','Let\'s go!','http://localhost:8000/wp-admin/themes.php?page=storefront-welcome','actioned','',NULL,NULL),(707,4,'browse_extensions','Browse extensions','http://localhost:8000/wp-admin/admin.php?page=wc-addons','unactioned','',NULL,NULL),(708,5,'wayflyer_bnpl_q4_2021','Level up with funding','https://woocommerce.com/products/wayflyer/?utm_source=inbox_note&utm_medium=product&utm_campaign=wayflyer_bnpl_q4_2021','actioned','',NULL,NULL),(709,6,'wc_shipping_mobile_app_usps_q4_2021','Get WooCommerce Shipping','https://woocommerce.com/woocommerce-shipping/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_usps_q4_2021','actioned','',NULL,NULL),(710,7,'learn-more','Learn more','https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox','unactioned','',NULL,NULL),(711,8,'learn-more','Learn more','https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more','actioned','',NULL,NULL),(712,9,'optimizing-the-checkout-flow','Learn more','https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox_note&utm_medium=product&utm_campaign=optimizing-the-checkout-flow','actioned','',NULL,NULL),(713,10,'qualitative-feedback-from-new-users','Share feedback','https://automattic.survey.fm/wc-pay-new','actioned','',NULL,NULL),(714,11,'share-feedback','Share feedback','http://automattic.survey.fm/paypal-feedback','unactioned','',NULL,NULL),(715,12,'get-started','Get started','https://woocommerce.com/products/google-listings-and-ads?utm_source=inbox_note&utm_medium=product&utm_campaign=get-started','actioned','',NULL,NULL),(716,13,'update-wc-subscriptions-3-0-15','View latest version','http://localhost:8000/wp-admin/&page=wc-addons&section=helper','actioned','',NULL,NULL),(717,14,'update-wc-core-5-4-0','How to update WooCommerce','https://docs.woocommerce.com/document/how-to-update-woocommerce/','actioned','',NULL,NULL),(718,17,'ppxo-pps-install-paypal-payments-1','View upgrade guide','https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/','actioned','',NULL,NULL),(719,18,'ppxo-pps-install-paypal-payments-2','View upgrade guide','https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/','actioned','',NULL,NULL),(720,19,'learn-more','Learn more','https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more','unactioned','',NULL,NULL),(721,19,'dismiss','Dismiss','','actioned','',NULL,NULL),(722,20,'learn-more','Learn more','https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more','unactioned','',NULL,NULL),(723,20,'dismiss','Dismiss','','actioned','',NULL,NULL),(724,21,'learn-more','Learn more','https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more','unactioned','',NULL,NULL),(725,21,'dismiss','Dismiss','','actioned','',NULL,NULL),(726,22,'learn-more','Learn more','https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more','unactioned','',NULL,NULL),(727,22,'dismiss','Dismiss','','actioned','',NULL,NULL),(728,23,'share-feedback','Share feedback','https://automattic.survey.fm/store-management','unactioned','',NULL,NULL),(729,24,'share-navigation-survey-feedback','Share feedback','https://automattic.survey.fm/feedback-on-woocommerce-navigation','actioned','',NULL,NULL),(730,25,'learn-more','Learn more','https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/','unactioned','',NULL,NULL),(731,25,'woocommerce-core-paypal-march-2022-dismiss','Dismiss','','actioned','',NULL,NULL),(732,26,'learn-more','Learn more','https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/','unactioned','',NULL,NULL),(733,26,'dismiss','Dismiss','','actioned','',NULL,NULL),(734,27,'pinterest_03_2022_update','Update Instructions','https://woocommerce.com/document/pinterest-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=pinterest_03_2022_update#section-3','actioned','',NULL,NULL),(735,28,'store_setup_survey_survey_q2_2022_share_your_thoughts','Tell us how it’s going','https://automattic.survey.fm/store-setup-survey-2022','actioned','',NULL,NULL),(736,29,'wc-admin-wisepad3','Grow my business offline','https://woocommerce.com/products/wisepad3-card-reader/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wisepad3','actioned','',NULL,NULL),(737,30,'learn-more','Find out more','https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/','unactioned','',NULL,NULL),(738,30,'dismiss','Dismiss','','actioned','',NULL,NULL),(739,31,'learn-more','Find out more','https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/','unactioned','',NULL,NULL),(740,31,'dismiss','Dismiss','','actioned','',NULL,NULL),(741,32,'shipping_category_q4_2022_click','Automate my shipping','https://woocommerce.com/product-category/woocommerce-extensions/shipping-delivery-and-fulfillment/?categoryIds=28685&collections=product&page=1&utm_source=inbox_note&utm_medium=product&utm_campaign=shipping_category_q4_2022_click','unactioned','',NULL,NULL),(742,33,'woocommerce_admin_deprecation_q4_2022','Deactivate WooCommerce Admin','http://localhost:8000/wp-admin/plugins.php','actioned','',NULL,NULL),(743,34,'tiktok-targeted-q4-2022-click','Launch a campaign','https://woocommerce.com/products/tiktok-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=tiktok-targeted-q4-2022-click','unactioned','',NULL,NULL),(744,35,'paypal_paylater_g3_q4_22','Install PayPal Payments','https://woocommerce.com/products/woocommerce-paypal-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=paypal_paylater_g3_q4_22','unactioned','',NULL,NULL),(745,36,'paypal_paylater_g2_q4_22','Install PayPal Payments','https://woocommerce.com/products/woocommerce-paypal-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=paypal_paylater_g2_q4_22','unactioned','',NULL,NULL);
/*!40000 ALTER TABLE `wp_wc_admin_note_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_admin_notes`
--

DROP TABLE IF EXISTS `wp_wc_admin_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_admin_notes` (
  `note_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `locale` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `status` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT '0',
  `layout` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `image` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `icon` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'info',
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_admin_notes`
--

LOCK TABLES `wp_wc_admin_notes` WRITE;
/*!40000 ALTER TABLE `wp_wc_admin_notes` DISABLE KEYS */;
INSERT INTO `wp_wc_admin_notes` VALUES (1,'wc-refund-returns-page','info','en_US','Setup a Refund and Returns Policy page to boost your store\'s credibility.','We have created a sample draft Refund and Returns Policy page for you. Please have a look and update it to fit your store.','{}','unactioned','woocommerce-core','2022-11-19 08:12:32',NULL,0,'plain','',0,0,'info'),(2,'wc-admin-wc-helper-connection','info','en_US','Connect to WooCommerce.com','Connect to get important product notifications and updates.','{}','unactioned','woocommerce-admin','2022-11-19 08:12:32',NULL,0,'plain','',0,0,'info'),(3,'wc-admin-install-jp-and-wcs-plugins','info','en_US','Uh oh... There was a problem during the Jetpack and WooCommerce Shipping & Tax install. Please try again.','We noticed that there was a problem during the Jetpack and WooCommerce Shipping &amp; Tax install. Please try again and enjoy all the advantages of having the plugins connected to your store! Sorry for the inconvenience. The \"Jetpack\" and \"WooCommerce Shipping &amp; Tax\" plugins will be installed &amp; activated for free.','{}','unactioned','woocommerce-admin','2022-11-19 08:14:43',NULL,0,'plain','',0,0,'info'),(4,'new_in_app_marketplace_2021','info','en_US','Customize your store with extensions','Check out our NEW Extensions tab to see our favorite extensions for customizing your store, and discover the most popular extensions in the WooCommerce Marketplace.','{}','unactioned','woocommerce.com','2022-11-19 08:22:00',NULL,0,'plain','',0,0,'info'),(5,'wayflyer_bnpl_q4_2021','marketing','en_US','Grow your business with funding through Wayflyer','Fast, flexible financing to boost cash flow and help your business grow – one fee, no interest rates, penalties, equity, or personal guarantees. Based on your store’s performance, Wayflyer provides funding and analytical insights to invest in your business.','{}','pending','woocommerce.com','2022-11-19 08:22:00',NULL,0,'plain','',0,0,'info'),(6,'wc_shipping_mobile_app_usps_q4_2021','marketing','en_US','Print and manage your shipping labels with WooCommerce Shipping and the WooCommerce Mobile App','Save time by printing, purchasing, refunding, and tracking shipping labels generated by <a href=\"https://woocommerce.com/woocommerce-shipping/\">WooCommerce Shipping</a> – all directly from your mobile device!','{}','pending','woocommerce.com','2022-11-19 08:22:00',NULL,0,'plain','',0,0,'info'),(7,'woocommerce-services','info','en_US','WooCommerce Shipping & Tax','WooCommerce Shipping &amp; Tax helps get your store \"ready to sell\" as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.','{}','pending','woocommerce.com','2022-11-19 08:22:00',NULL,0,'plain','',0,0,'info'),(8,'your-first-product','info','en_US','Your first product','That’s huge! You’re well on your way to building a successful online store — now it’s time to think about how you’ll fulfill your orders.<br /><br />Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href=\"https://href.li/?https://woocommerce.com/shipping\" target=\"_blank\">WooCommerce Shipping</a>.','{}','unactioned','woocommerce.com','2022-11-19 12:12:44',NULL,0,'plain','',0,0,'info'),(9,'wc-admin-optimizing-the-checkout-flow','info','en_US','Optimizing the checkout flow','It’s crucial to get your store’s checkout as smooth as possible to avoid losing sales. Let’s take a look at how you can optimize the checkout experience for your shoppers.','{}','unactioned','woocommerce.com','2022-11-23 05:20:14',NULL,0,'plain','',0,0,'info'),(10,'wc-payments-qualitative-feedback','info','en_US','WooCommerce Payments setup - let us know what you think','Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.','{}','pending','woocommerce.com','2022-11-19 08:22:00',NULL,0,'plain','',0,0,'info'),(11,'share-your-feedback-on-paypal','info','en_US','Share your feedback on PayPal','Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.','{}','pending','woocommerce.com','2022-11-19 08:22:00',NULL,0,'plain','',0,0,'info'),(12,'google_listings_and_ads_install','marketing','en_US','Drive traffic and sales with Google','Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.','{}','pending','woocommerce.com','2022-11-19 08:22:00',NULL,0,'plain','',0,0,'info'),(13,'wc-subscriptions-security-update-3-0-15','info','en_US','WooCommerce Subscriptions security update!','We recently released an important security update to WooCommerce Subscriptions. To ensure your site’s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br /><br />Click the button below to view and update to the latest Subscriptions version, or log in to <a href=\"https://woocommerce.com/my-dashboard\">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br /><br />We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br /><br />If you have any questions we are here to help — just <a href=\"https://woocommerce.com/my-account/create-a-ticket/\">open a ticket</a>.','{}','pending','woocommerce.com','2022-11-19 08:22:00',NULL,0,'plain','',0,0,'info'),(14,'woocommerce-core-update-5-4-0','info','en_US','Update to WooCommerce 5.4.1 now','WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(15,'wcpay-promo-2020-11','marketing','en_US','wcpay-promo-2020-11','wcpay-promo-2020-11','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(16,'wcpay-promo-2020-12','marketing','en_US','wcpay-promo-2020-12','wcpay-promo-2020-12','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(17,'ppxo-pps-upgrade-paypal-payments-1','info','en_US','Get the latest PayPal extension for WooCommerce','Heads up! There’s a new PayPal on the block!<br /><br />Now is a great time to upgrade to our latest <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal extension</a> to continue to receive support and updates with PayPal.<br /><br />Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(18,'ppxo-pps-upgrade-paypal-payments-2','info','en_US','Upgrade your PayPal experience!','Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br /><br />Start using our <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">latest PayPal today</a> to continue to receive support and updates.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(19,'woocommerce-core-sqli-july-2021-need-to-update','update','en_US','Action required: Critical vulnerabilities in WooCommerce','In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(20,'woocommerce-blocks-sqli-july-2021-need-to-update','update','en_US','Action required: Critical vulnerabilities in WooCommerce Blocks','In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(21,'woocommerce-core-sqli-july-2021-store-patched','update','en_US','Solved: Critical vulnerabilities patched in WooCommerce','In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(22,'woocommerce-blocks-sqli-july-2021-store-patched','update','en_US','Solved: Critical vulnerabilities patched in WooCommerce Blocks','In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(23,'habit-moment-survey','marketing','en_US','We’re all ears! Share your experience so far with WooCommerce','We’d love your input to shape the future of WooCommerce together. Feel free to share any feedback, ideas or suggestions that you have.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(24,'ecomm-wc-navigation-survey','info','en_US','We’d like your feedback on the WooCommerce navigation','We’re making improvements to the WooCommerce navigation and would love your feedback. Share your experience in this 2 minute survey.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(25,'woocommerce-core-paypal-march-2022-updated','update','en_US','Security auto-update of WooCommerce','<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy PayPal Standard security updates for stores running WooCommerce (version 3.5 to 6.3). It’s recommended to disable PayPal Standard, and use <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal Payments</a> to accept PayPal.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(26,'woocommerce-core-paypal-march-2022-updated-nopp','update','en_US','Security auto-update of WooCommerce','<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy security updates related to PayPal Standard payment gateway for stores running WooCommerce (version 3.5 to 6.3).','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(27,'pinterest_03_2022_update','marketing','en_US','Your Pinterest for WooCommerce plugin is out of date!','Update to the latest version of Pinterest for WooCommerce to continue using this plugin and keep your store connected with Pinterest. To update, visit <strong>Plugins &gt; Installed Plugins</strong>, and click on “update now” under Pinterest for WooCommerce.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(28,'store_setup_survey_survey_q2_2022','survey','en_US','How is your store setup going?','Our goal is to make sure you have all the right tools to start setting up your store in the smoothest way possible.\r\nWe’d love to know if we hit our mark and how we can improve. To collect your thoughts, we made a 2-minute survey.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(29,'wc-admin-wisepad3','marketing','en_US','Take your business on the go in Canada with WooCommerce In-Person Payments','Quickly create new orders, accept payment in person for orders placed online, and automatically sync your inventory – no matter where your business takes you. With WooCommerce In-Person Payments and the WisePad 3 card reader, you can bring the power of your store anywhere.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(30,'woocommerce-payments-august-2022-need-to-update','update','en_US','Action required: Please update WooCommerce Payments','An updated secure version of WooCommerce Payments is available – please ensure that you’re using the latest patch version. For more information on what action you need to take, please review the article below.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(31,'woocommerce-payments-august-2022-store-patched','update','en_US','WooCommerce Payments has been automatically updated','You’re now running the latest secure version of WooCommerce Payments. We’ve worked with the WordPress Plugins team to deploy a security update to stores running WooCommerce Payments (version 3.9 to 4.5). For further information, please review the article below.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(32,'shipping_category_q4_2022','marketing','en_US','Save time on shipping','Is your store all set to ship? Save valuable time (and money!) by automating your fulfillment process for the busiest shopping season. Explore our range of trusted shipping partners to get started.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(33,'woocommerce_admin_deprecation_q4_2022','info','en_US','WooCommerce Admin is part of WooCommerce!','To make sure your store continues to run smoothly, check that WooCommerce is up-to-date – at least version 6.5 – and then disable the WooCommerce Admin plugin.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(34,'tiktok-targeted-q4-2022','marketing','en_US','Get $200 in ad credit from TikTok after you spend $20 on your first campaign','Reach one billion shoppers with TikTok for WooCommerce this holiday season! Sync your product catalog, capture insights, and create ad campaigns right from your dashboard. Connect your store today to unlock this limited time offer! <a href=\"https://ads.tiktok.com/help/article?aid=10011326\">Terms &amp; conditions apply</a>.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(35,'paypal_paylater_g3_q4_22','marketing','en_US','Turn browsers into buyers with Pay Later','Add PayPal at checkout, plus give customers a buy now, pay later option from the name they trust. With Pay in 4 &amp; Pay Monthly, available in PayPal Payments, you get paid up front while letting customers spread their payments over time. Boost your average order value and convert more sales – at no extra cost to you.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(36,'paypal_paylater_g2_q4_22','marketing','en_US','Upgrade to PayPal Payments to offer Pay Later at checkout','PayPal Pay Later is included in PayPal Payments at no additional cost to you. Customers can spread their payments over time while you get paid up front. \r\nThere’s never been a better time to upgrade your PayPal plugin. Simply download it and connect with a PayPal Business account.','{}','pending','woocommerce.com','2022-11-19 08:22:01',NULL,0,'plain','',0,0,'info'),(37,'storefront-customize','info','en_US','Design your store with Storefront 🎨','Visit the Storefront settings page to start setup and customization of your shop.','{}','unactioned','storefront','2022-11-19 08:25:14',NULL,0,'plain','',0,0,'info');
/*!40000 ALTER TABLE `wp_wc_admin_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_category_lookup`
--

DROP TABLE IF EXISTS `wp_wc_category_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_category_lookup` (
  `category_tree_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`category_tree_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_category_lookup`
--

LOCK TABLES `wp_wc_category_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_category_lookup` DISABLE KEYS */;
INSERT INTO `wp_wc_category_lookup` VALUES (16,16),(16,17),(17,17);
/*!40000 ALTER TABLE `wp_wc_category_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_customer_lookup`
--

DROP TABLE IF EXISTS `wp_wc_customer_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_customer_lookup` (
  `customer_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `username` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_customer_lookup`
--

LOCK TABLES `wp_wc_customer_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_customer_lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_customer_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_download_log`
--

DROP TABLE IF EXISTS `wp_wc_download_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`),
  CONSTRAINT `fk_wp_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_download_log`
--

LOCK TABLES `wp_wc_download_log` WRITE;
/*!40000 ALTER TABLE `wp_wc_download_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_download_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_order_coupon_lookup`
--

DROP TABLE IF EXISTS `wp_wc_order_coupon_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_order_coupon_lookup` (
  `order_id` bigint unsigned NOT NULL,
  `coupon_id` bigint NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`coupon_id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_order_coupon_lookup`
--

LOCK TABLES `wp_wc_order_coupon_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_order_coupon_lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_order_coupon_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_order_product_lookup`
--

DROP TABLE IF EXISTS `wp_wc_order_product_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_order_product_lookup` (
  `order_item_id` bigint unsigned NOT NULL,
  `order_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `variation_id` bigint unsigned NOT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT '0',
  `product_gross_revenue` double NOT NULL DEFAULT '0',
  `coupon_amount` double NOT NULL DEFAULT '0',
  `tax_amount` double NOT NULL DEFAULT '0',
  `shipping_amount` double NOT NULL DEFAULT '0',
  `shipping_tax_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_order_product_lookup`
--

LOCK TABLES `wp_wc_order_product_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_order_product_lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_order_product_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_order_stats`
--

DROP TABLE IF EXISTS `wp_wc_order_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_order_stats` (
  `order_id` bigint unsigned NOT NULL,
  `parent_id` bigint unsigned NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int NOT NULL DEFAULT '0',
  `total_sales` double NOT NULL DEFAULT '0',
  `tax_total` double NOT NULL DEFAULT '0',
  `shipping_total` double NOT NULL DEFAULT '0',
  `net_total` double NOT NULL DEFAULT '0',
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `customer_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_order_stats`
--

LOCK TABLES `wp_wc_order_stats` WRITE;
/*!40000 ALTER TABLE `wp_wc_order_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_order_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_order_tax_lookup`
--

DROP TABLE IF EXISTS `wp_wc_order_tax_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_order_tax_lookup` (
  `order_id` bigint unsigned NOT NULL,
  `tax_rate_id` bigint unsigned NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT '0',
  `order_tax` double NOT NULL DEFAULT '0',
  `total_tax` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`tax_rate_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_order_tax_lookup`
--

LOCK TABLES `wp_wc_order_tax_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_order_tax_lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_order_tax_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_product_attributes_lookup`
--

DROP TABLE IF EXISTS `wp_wc_product_attributes_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_product_attributes_lookup` (
  `product_id` bigint NOT NULL,
  `product_or_parent_id` bigint NOT NULL,
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `term_id` bigint NOT NULL,
  `is_variation_attribute` tinyint(1) NOT NULL,
  `in_stock` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_or_parent_id`,`term_id`,`product_id`,`taxonomy`),
  KEY `is_variation_attribute_term_id` (`is_variation_attribute`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_product_attributes_lookup`
--

LOCK TABLES `wp_wc_product_attributes_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_product_attributes_lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_product_attributes_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_product_download_directories`
--

DROP TABLE IF EXISTS `wp_wc_product_download_directories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_product_download_directories` (
  `url_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`url_id`),
  KEY `url` (`url`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_product_download_directories`
--

LOCK TABLES `wp_wc_product_download_directories` WRITE;
/*!40000 ALTER TABLE `wp_wc_product_download_directories` DISABLE KEYS */;
INSERT INTO `wp_wc_product_download_directories` VALUES (1,'file:///var/www/html/wp-content/uploads/woocommerce_uploads/',1),(2,'http://localhost:8000/wp-content/uploads/woocommerce_uploads/',1);
/*!40000 ALTER TABLE `wp_wc_product_download_directories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_product_meta_lookup`
--

DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint NOT NULL,
  `sku` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT '0',
  `downloadable` tinyint(1) DEFAULT '0',
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT '0',
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT 'instock',
  `rating_count` bigint DEFAULT '0',
  `average_rating` decimal(3,2) DEFAULT '0.00',
  `total_sales` bigint DEFAULT '0',
  `tax_status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT 'taxable',
  `tax_class` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_product_meta_lookup`
--

LOCK TABLES `wp_wc_product_meta_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_product_meta_lookup` DISABLE KEYS */;
INSERT INTO `wp_wc_product_meta_lookup` VALUES (11,'',0,0,40.0000,40.0000,1,NULL,'instock',0,0.00,13,'taxable','');
/*!40000 ALTER TABLE `wp_wc_product_meta_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_rate_limits`
--

DROP TABLE IF EXISTS `wp_wc_rate_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_rate_limits` (
  `rate_limit_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `rate_limit_key` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `rate_limit_expiry` bigint unsigned NOT NULL,
  `rate_limit_remaining` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`rate_limit_id`),
  UNIQUE KEY `rate_limit_key` (`rate_limit_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_rate_limits`
--

LOCK TABLES `wp_wc_rate_limits` WRITE;
/*!40000 ALTER TABLE `wp_wc_rate_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_rate_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_reserved_stock`
--

DROP TABLE IF EXISTS `wp_wc_reserved_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_reserved_stock` (
  `order_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT '0',
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_reserved_stock`
--

LOCK TABLES `wp_wc_reserved_stock` WRITE;
/*!40000 ALTER TABLE `wp_wc_reserved_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_reserved_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_tax_rate_classes`
--

DROP TABLE IF EXISTS `wp_wc_tax_rate_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_tax_rate_classes`
--

LOCK TABLES `wp_wc_tax_rate_classes` WRITE;
/*!40000 ALTER TABLE `wp_wc_tax_rate_classes` DISABLE KEYS */;
INSERT INTO `wp_wc_tax_rate_classes` VALUES (1,'Reduced rate','reduced-rate'),(2,'Zero rate','zero-rate');
/*!40000 ALTER TABLE `wp_wc_tax_rate_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_webhooks`
--

DROP TABLE IF EXISTS `wp_wc_webhooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `delivery_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint NOT NULL,
  `failure_count` smallint NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_webhooks`
--

LOCK TABLES `wp_wc_webhooks` WRITE;
/*!40000 ALTER TABLE `wp_wc_webhooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_webhooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_api_keys`
--

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_api_keys`
--

LOCK TABLES `wp_woocommerce_api_keys` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_api_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_attribute_taxonomies`
--

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_attribute_taxonomies`
--

LOCK TABLES `wp_woocommerce_attribute_taxonomies` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_attribute_taxonomies` DISABLE KEYS */;
INSERT INTO `wp_woocommerce_attribute_taxonomies` VALUES (1,'color','Color','select','menu_order',0);
/*!40000 ALTER TABLE `wp_woocommerce_attribute_taxonomies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_downloadable_product_permissions`
--

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `order_id` bigint unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`),
  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_downloadable_product_permissions`
--

LOCK TABLES `wp_woocommerce_downloadable_product_permissions` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_downloadable_product_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_downloadable_product_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_log`
--

DROP TABLE IF EXISTS `wp_woocommerce_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint NOT NULL,
  `source` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_log`
--

LOCK TABLES `wp_woocommerce_log` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_order_itemmeta`
--

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint unsigned NOT NULL,
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB AUTO_INCREMENT=481 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_order_itemmeta`
--

LOCK TABLES `wp_woocommerce_order_itemmeta` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_order_itemmeta` DISABLE KEYS */;
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES (46,7,'_product_id','11'),(47,7,'_variation_id','0'),(48,7,'_qty','1'),(49,7,'_tax_class',''),(50,7,'_line_subtotal','45'),(51,7,'_line_subtotal_tax','0'),(52,7,'_line_total','45'),(53,7,'_line_tax','0'),(54,7,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),(55,8,'method_id','free_shipping'),(56,8,'instance_id','1'),(57,8,'cost','0.00'),(58,8,'total_tax','0'),(59,8,'taxes','a:1:{s:5:\"total\";a:0:{}}'),(60,8,'Items','Lorem Ipsum &times; 1'),(106,15,'_product_id','11'),(107,15,'_variation_id','0'),(108,15,'_qty','2'),(109,15,'_tax_class',''),(110,15,'_line_subtotal','90'),(111,15,'_line_subtotal_tax','0'),(112,15,'_line_total','90'),(113,15,'_line_tax','0'),(114,15,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),(115,16,'method_id','free_shipping'),(116,16,'instance_id','1'),(117,16,'cost','0.00'),(118,16,'total_tax','0'),(119,16,'taxes','a:1:{s:5:\"total\";a:0:{}}'),(120,16,'Items','Lorem Ipsum &times; 2'),(256,35,'_product_id','11'),(257,35,'_variation_id','0'),(258,35,'_qty','2'),(259,35,'_tax_class',''),(260,35,'_line_subtotal','80'),(261,35,'_line_subtotal_tax','0'),(262,35,'_line_total','80'),(263,35,'_line_tax','0'),(264,35,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),(265,36,'method_id','free_shipping'),(266,36,'instance_id','1'),(267,36,'cost','0.00'),(268,36,'total_tax','0'),(269,36,'taxes','a:1:{s:5:\"total\";a:0:{}}'),(270,36,'Items','Lorem Ipsum &times; 2'),(316,43,'_product_id','11'),(317,43,'_variation_id','0'),(318,43,'_qty','1'),(319,43,'_tax_class',''),(320,43,'_line_subtotal','40'),(321,43,'_line_subtotal_tax','0'),(322,43,'_line_total','40'),(323,43,'_line_tax','0'),(324,43,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),(325,44,'method_id','free_shipping'),(326,44,'instance_id','1'),(327,44,'cost','0.00'),(328,44,'total_tax','0'),(329,44,'taxes','a:1:{s:5:\"total\";a:0:{}}'),(330,44,'Items','Lorem Ipsum &times; 1'),(376,51,'_product_id','11'),(377,51,'_variation_id','0'),(378,51,'_qty','1'),(379,51,'_tax_class',''),(380,51,'_line_subtotal','40'),(381,51,'_line_subtotal_tax','0'),(382,51,'_line_total','40'),(383,51,'_line_tax','0'),(384,51,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),(385,52,'method_id','free_shipping'),(386,52,'instance_id','2'),(387,52,'cost','0.00'),(388,52,'total_tax','0'),(389,52,'taxes','a:1:{s:5:\"total\";a:0:{}}'),(390,52,'Items','Lorem Ipsum &times; 1'),(391,53,'_product_id','11'),(392,53,'_variation_id','0'),(393,53,'_qty','1'),(394,53,'_tax_class',''),(395,53,'_line_subtotal','40'),(396,53,'_line_subtotal_tax','0'),(397,53,'_line_total','40'),(398,53,'_line_tax','0'),(399,53,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),(400,54,'method_id','free_shipping'),(401,54,'instance_id','2'),(402,54,'cost','0.00'),(403,54,'total_tax','0'),(404,54,'taxes','a:1:{s:5:\"total\";a:0:{}}'),(405,54,'Items','Lorem Ipsum &times; 1'),(406,55,'_product_id','11'),(407,55,'_variation_id','0'),(408,55,'_qty','1'),(409,55,'_tax_class',''),(410,55,'_line_subtotal','40'),(411,55,'_line_subtotal_tax','0'),(412,55,'_line_total','40'),(413,55,'_line_tax','0'),(414,55,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),(415,56,'method_id','free_shipping'),(416,56,'instance_id','2'),(417,56,'cost','0.00'),(418,56,'total_tax','0'),(419,56,'taxes','a:1:{s:5:\"total\";a:0:{}}'),(420,56,'Items','Lorem Ipsum &times; 1'),(421,57,'_product_id','11'),(422,57,'_variation_id','0'),(423,57,'_qty','1'),(424,57,'_tax_class',''),(425,57,'_line_subtotal','40'),(426,57,'_line_subtotal_tax','0'),(427,57,'_line_total','40'),(428,57,'_line_tax','0'),(429,57,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),(430,58,'method_id','free_shipping'),(431,58,'instance_id','2'),(432,58,'cost','0.00'),(433,58,'total_tax','0'),(434,58,'taxes','a:1:{s:5:\"total\";a:0:{}}'),(435,58,'Items','Lorem Ipsum &times; 1'),(436,59,'_product_id','11'),(437,59,'_variation_id','0'),(438,59,'_qty','1'),(439,59,'_tax_class',''),(440,59,'_line_subtotal','40'),(441,59,'_line_subtotal_tax','0'),(442,59,'_line_total','40'),(443,59,'_line_tax','0'),(444,59,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),(445,60,'method_id','free_shipping'),(446,60,'instance_id','2'),(447,60,'cost','0.00'),(448,60,'total_tax','0'),(449,60,'taxes','a:1:{s:5:\"total\";a:0:{}}'),(450,60,'Items','Lorem Ipsum &times; 1'),(451,61,'_product_id','11'),(452,61,'_variation_id','0'),(453,61,'_qty','3'),(454,61,'_tax_class',''),(455,61,'_line_subtotal','120'),(456,61,'_line_subtotal_tax','0'),(457,61,'_line_total','120'),(458,61,'_line_tax','0'),(459,61,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),(460,62,'method_id','free_shipping'),(461,62,'instance_id','2'),(462,62,'cost','0.00'),(463,62,'total_tax','0'),(464,62,'taxes','a:1:{s:5:\"total\";a:0:{}}'),(465,62,'Items','Lorem Ipsum &times; 3'),(466,63,'_product_id','11'),(467,63,'_variation_id','0'),(468,63,'_qty','1'),(469,63,'_tax_class',''),(470,63,'_line_subtotal','40'),(471,63,'_line_subtotal_tax','0'),(472,63,'_line_total','40'),(473,63,'_line_tax','0'),(474,63,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),(475,64,'method_id','free_shipping'),(476,64,'instance_id','2'),(477,64,'cost','0.00'),(478,64,'total_tax','0'),(479,64,'taxes','a:1:{s:5:\"total\";a:0:{}}'),(480,64,'Items','Lorem Ipsum &times; 1');
/*!40000 ALTER TABLE `wp_woocommerce_order_itemmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_order_items`
--

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_order_items`
--

LOCK TABLES `wp_woocommerce_order_items` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_order_items` DISABLE KEYS */;
INSERT INTO `wp_woocommerce_order_items` VALUES (7,'Lorem Ipsum','line_item',19),(8,'Free shipping','shipping',19),(15,'Lorem Ipsum','line_item',20),(16,'Free shipping','shipping',20),(35,'Lorem Ipsum','line_item',21),(36,'Free shipping','shipping',21),(43,'Lorem Ipsum','line_item',22),(44,'Free shipping','shipping',22),(51,'Lorem Ipsum','line_item',23),(52,'Free shipping','shipping',23),(53,'Lorem Ipsum','line_item',31),(54,'Free shipping','shipping',31),(55,'Lorem Ipsum','line_item',32),(56,'Free shipping','shipping',32),(57,'Lorem Ipsum','line_item',46),(58,'Free shipping','shipping',46),(59,'Lorem Ipsum','line_item',47),(60,'Free shipping','shipping',47),(61,'Lorem Ipsum','line_item',49),(62,'Free shipping','shipping',49),(63,'Lorem Ipsum','line_item',50),(64,'Free shipping','shipping',50);
/*!40000 ALTER TABLE `wp_woocommerce_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_payment_tokenmeta`
--

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint unsigned NOT NULL,
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_payment_tokenmeta`
--

LOCK TABLES `wp_woocommerce_payment_tokenmeta` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_payment_tokenmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_payment_tokenmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_payment_tokens`
--

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_payment_tokens`
--

LOCK TABLES `wp_woocommerce_payment_tokens` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_payment_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_payment_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_sessions`
--

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_sessions`
--

LOCK TABLES `wp_woocommerce_sessions` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_sessions` DISABLE KEYS */;
INSERT INTO `wp_woocommerce_sessions` VALUES (1,'1','a:14:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:948:\"a:27:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2022-11-28T08:32:11+00:00\";s:8:\"postcode\";s:4:\"1111\";s:4:\"city\";s:9:\"徐汇区\";s:9:\"address_1\";s:20:\"襄阳南路489号4F\";s:7:\"address\";s:20:\"襄阳南路489号4F\";s:9:\"address_2\";s:12:\"金环大厦\";s:5:\"state\";s:9:\"HONG KONG\";s:7:\"country\";s:2:\"HK\";s:17:\"shipping_postcode\";s:4:\"1111\";s:13:\"shipping_city\";s:9:\"徐汇区\";s:18:\"shipping_address_1\";s:20:\"襄阳南路489号4F\";s:16:\"shipping_address\";s:20:\"襄阳南路489号4F\";s:18:\"shipping_address_2\";s:12:\"金环大厦\";s:14:\"shipping_state\";s:9:\"HONG KONG\";s:16:\"shipping_country\";s:2:\"HK\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:3:\"YAO\";s:9:\"last_name\";s:8:\"YINGYING\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:11:\"18601660362\";s:5:\"email\";s:17:\"yao3060@gmail.com\";s:19:\"shipping_first_name\";s:3:\"YAO\";s:18:\"shipping_last_name\";s:8:\"YINGYING\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";}\";s:22:\"shipping_for_package_0\";s:395:\"a:2:{s:12:\"package_hash\";s:40:\"wc_ship_ddca853df5c83370aa7c24f8276ac5c8\";s:5:\"rates\";a:1:{s:15:\"free_shipping:2\";O:16:\"WC_Shipping_Rate\":2:{s:7:\"\0*\0data\";a:6:{s:2:\"id\";s:15:\"free_shipping:2\";s:9:\"method_id\";s:13:\"free_shipping\";s:11:\"instance_id\";i:2;s:5:\"label\";s:13:\"Free shipping\";s:4:\"cost\";s:4:\"0.00\";s:5:\"taxes\";a:0:{}}s:12:\"\0*\0meta_data\";a:1:{s:5:\"Items\";s:21:\"Lorem Ipsum &times; 1\";}}}}\";s:25:\"previous_shipping_methods\";s:43:\"a:1:{i:0;a:1:{i:0;s:15:\"free_shipping:2\";}}\";s:23:\"chosen_shipping_methods\";s:33:\"a:1:{i:0;s:15:\"free_shipping:2\";}\";s:22:\"shipping_method_counts\";s:14:\"a:1:{i:0;i:1;}\";s:10:\"wc_notices\";N;s:21:\"chosen_payment_method\";s:8:\"payermax\";s:22:\"order_awaiting_payment\";N;}',1669786573);
/*!40000 ALTER TABLE `wp_woocommerce_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_shipping_zone_locations`
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint unsigned NOT NULL,
  `location_code` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_shipping_zone_locations`
--

LOCK TABLES `wp_woocommerce_shipping_zone_locations` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_shipping_zone_locations` DISABLE KEYS */;
INSERT INTO `wp_woocommerce_shipping_zone_locations` VALUES (1,1,'CN','country'),(2,2,'HK','country');
/*!40000 ALTER TABLE `wp_woocommerce_shipping_zone_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_shipping_zone_methods`
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint unsigned NOT NULL,
  `instance_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_shipping_zone_methods`
--

LOCK TABLES `wp_woocommerce_shipping_zone_methods` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_shipping_zone_methods` DISABLE KEYS */;
INSERT INTO `wp_woocommerce_shipping_zone_methods` VALUES (1,1,'free_shipping',1,1),(2,2,'free_shipping',1,1);
/*!40000 ALTER TABLE `wp_woocommerce_shipping_zone_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_shipping_zones`
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_shipping_zones`
--

LOCK TABLES `wp_woocommerce_shipping_zones` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_shipping_zones` DISABLE KEYS */;
INSERT INTO `wp_woocommerce_shipping_zones` VALUES (1,'China',0),(2,'Hong Kong',0);
/*!40000 ALTER TABLE `wp_woocommerce_shipping_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_tax_rate_locations`
--

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint unsigned NOT NULL,
  `location_type` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_tax_rate_locations`
--

LOCK TABLES `wp_woocommerce_tax_rate_locations` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_tax_rate_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_tax_rate_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_tax_rates`
--

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint unsigned NOT NULL,
  `tax_rate_compound` int NOT NULL DEFAULT '0',
  `tax_rate_shipping` int NOT NULL DEFAULT '1',
  `tax_rate_order` bigint unsigned NOT NULL,
  `tax_rate_class` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_tax_rates`
--

LOCK TABLES `wp_woocommerce_tax_rates` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-28  8:57:37
